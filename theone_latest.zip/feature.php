<?php
    $error = '';
    $selectedSoftware = ''; // Initialize $selectedSoftware

    if (isset($_GET['software']) && isset($_GET['from_date']) && isset($_GET['to_date'])) {
        $selectedSoftware = $_GET['software'];
        $fromDate = $_GET['from_date'];
        $toDate = $_GET['to_date'];
    } else {
        $error = 'Invalid request. Please go back and fill out the form.';
    }

    include("src/Model/User.php");
    include("view/Graph.php");
    $table = "licenseuserhistory_correct2";
    $user = new User;
    $graph = new Graph;
    $conn = $user->getConnection("localhost", "hpc", "root", "");

    $dataPoints1 = $graph->getFeatureFromTo($conn, $user, $table, $selectedSoftware, $fromDate, $toDate);
    $dataPoints2 = $graph->getUserPerFeature($conn, $user, $table, $selectedSoftware, $fromDate, $toDate);
    $dataPoints3 = $graph->getFeatureStats($conn, $user, $table, $selectedSoftware, $fromDate, $toDate);


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($selectedSoftware) ?>'s Feature Analysis</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-moment"></script>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: #f2f2f2;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            text-align: center;
            width: 65%;
            margin: auto;
        }
        .container h1, .container h2 {
            margin-bottom: 20px;
            color: #333;
        }
        .error {
            color: red;
            font-size: 14px;
            margin-bottom: 10px;
        }
        .button {
            padding: 10px 20px;
            font-size: 16px;
            background: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
        }
        .button:hover {
            background: #0056b3;
        }
        .chartContainer {
            margin-top: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 100%;
            max-height: 500px; /* Adjust height as needed */
        }
    </style>
</head>
<body>
    <div class="container">
        <?php if (!empty($selectedSoftware)) : ?>
            <h1><?php echo htmlspecialchars($selectedSoftware) ?>'s Feature Analysis</h1>
            
            <?php if (!empty($error)) : ?>
                <div class="error"><?php echo $error; ?></div>
                <a href="index.php" class="button">Go Back to Index</a>
            <?php else : ?>
                <p>Date range: <?php echo htmlspecialchars($fromDate) ?> to <?php echo htmlspecialchars($toDate) ?></p>
                
                <!-- Canvas containers for charts -->
                <canvas id="chartContainer3" class="chartContainer"></canvas>
                <canvas id="chartContainer1" class="chartContainer"></canvas>
                <canvas id="chartContainer2" class="chartContainer"></canvas>
    
                <a href="user.php?software=<?php echo urlencode($selectedSoftware); ?>&from_date=<?php echo urlencode($fromDate); ?>&to_date=<?php echo urlencode($toDate); ?>" class="button">Explore It's Users</a>
            <?php endif; ?>
        <?php else : ?>
            <h1>Error</h1>
            <p><?php echo $error; ?></p>
            <a href="index.php" class="button">Go Back to Index</a>
        <?php endif; ?>
    </div>
    <script>
        window.onload = function() {
            var datasets1 = [];
            <?php foreach ($dataPoints1 as $feature => $data) : ?>
                datasets1.push({
                    label: '<?php echo htmlspecialchars($feature); ?>',
                    data: <?php echo json_encode(array_map(function($entry) {
                        return ['x' => $entry['date'], 'y' => $entry['avg_licenses']];
                    }, $data)); ?>,
                    borderWidth: 1,
                    fill: false,
                    spanGaps: true, // Ensure gaps are handled
                    hidden: true
                });
            <?php endforeach; ?>

            var ctx1 = document.getElementById('chartContainer1').getContext('2d');
            var chart1 = new Chart(ctx1, {
                type: 'line',
                data: {
                    datasets: datasets1
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: false,
                            title: {
                                display: true,
                                text: 'Average License Issued',
                                font: {
                                    size: 16,
                                    family: 'Arial',
                                    style: 'normal',
                                    lineHeight: 1.2
                                },
                                color: '#000',
                                padding: { top: 10, left: 0, right: 0, bottom: 10 }
                            }
                        },
                        x: {
                            type: 'time',
                            time: {
                                unit: 'day', // Adjust based on your data density
                                tooltipFormat: 'll',
                                displayFormats: {
                                    day: 'MMM D',
                                }
                            },
                            title: {
                                display: true,
                                text: 'Date',
                                font: {
                                    size: 16,
                                    family: 'Arial',
                                    style: 'normal',
                                    lineHeight: 1.2
                                },
                                color: '#000',
                                padding: { top: 10, left: 0, right: 0, bottom: 10 }
                            }
                        }
                    },
                    plugins: {
                        tooltip: {
                            mode: 'index',
                            intersect: false
                        },
                        interaction: {
                            mode: 'index',
                            intersect: false
                        },
                        title: {
                            display: true,
                            text: 'Average Number of Licenses Issued for <?php echo htmlspecialchars($selectedSoftware); ?> Features',
                            padding: {
                                top: 10,
                                bottom: 10
                            },
                            font: {
                                size: 20
                            }
                        }
                    }
                }
            });


            var datasets2 = [];
            <?php foreach ($dataPoints2 as $feature => $data) : ?>
                datasets2.push({
                    label: '<?php echo htmlspecialchars($feature); ?>',
                    data: <?php echo json_encode(array_map(function($entry) {
                        return ['x' => $entry['date'], 'y' => $entry['user_count']];
                    }, $data)); ?>,
                    borderWidth: 1,
                    fill: false,
                    spanGaps: true, // Adjusted to handle gaps
                    pointBackgroundColor: 'rgba(75, 192, 192, 0.6)',
                    pointBorderColor: 'rgba(75, 192, 192, 1)',
                    pointBorderWidth: 1,
                    pointRadius: 2,
                    hidden: true
                });
            <?php endforeach; ?>

            var ctx2 = document.getElementById('chartContainer2').getContext('2d');
            var chart2 = new Chart(ctx2, {
                type: 'line',
                data: {
                    datasets: datasets2
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Number of Users',
                                font: {
                                    size: 16,
                                    family: 'Arial',
                                    style: 'normal',
                                    lineHeight: 1.2
                                },
                                color: '#000',
                                padding: {top: 10, left: 0, right: 0, bottom: 10}
                            }
                        },
                        x: {
                            type: 'time', // Adjusted to handle dates as time series
                            time: {
                                unit: 'day', // Adjust based on your data density
                                tooltipFormat: 'll',
                                displayFormats: {
                                    day: 'MMM D',
                                }
                            },
                            title: {
                                display: true,
                                text: 'Date',
                                font: {
                                    size: 16,
                                    family: 'Arial',
                                    style: 'normal',
                                    lineHeight: 1.2
                                },
                                color: '#000',
                                padding: {top: 10, left: 0, right: 0, bottom: 10}
                            }
                        }
                    },
                    plugins: {
                        tooltip: {
                            mode: 'index',
                            intersect: false,
                            callbacks: {
                                label: function(context) {
                                    var users = <?php echo json_encode(array_map(function($data) { return $data['users']; }, $dataPoints2[$feature])); ?>;
                                    return context.raw.y + ': ' + users[context.dataIndex];
                                }
                            }
                        },
                        interaction: {
                            mode: 'index',
                            intersect: false
                        },
                        title: {
                            display: true,
                            text: 'Number of <?php echo htmlspecialchars($selectedSoftware); ?> Users per Feature',
                            padding: {
                                top: 10,
                                bottom: 10
                            },
                            font: {
                                size: 20
                            }
                        }
                    }
                }
            });


            var ctx3 = document.getElementById('chartContainer3').getContext('2d');
            var chart3 = new Chart(ctx3, {
                type: 'pie',
                data: {
                    labels: <?php echo json_encode(array_column($dataPoints3, 'feature')); ?>,
                    datasets: [{
                        label: 'Licenses Issued per Feature',
                        data: <?php echo json_encode(array_column($dataPoints3, 'no_licenses')); ?>,
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        title: {
                            display: true,
                            text: 'Licenses Issued per Feature for <?php echo htmlspecialchars($selectedSoftware); ?>',
                            padding: {
                                top: 10,
                                bottom: 10
                            },
                            font: {
                                size: 20
                            }
                        }
                    }
                }
            });



        
        }
    </script>
</body>
</html>
