<?php
    $error = '';
    $selectedSoftware = ''; // Initialize $selectedSoftware
    
    if (isset($_GET['software']) && isset($_GET['from_date']) && isset($_GET['to_date'])) {
        $selectedSoftware = $_GET['software'];
        $fromDate = $_GET['from_date'];
        $toDate = $_GET['to_date'];
    } else {
        $error = 'Invalid request. Please go back and fill out the form.';
    }

    include("src/Model/User.php");
    include("view/Graph.php");
    $table = "licenseuserhistory_correct2";
    $user = new User;
    $graph = new Graph;
    $conn = $user->getConnection("localhost", "hpc", "root", "");
	
	function printDuration($start_time, $message) {
		$end_time = microtime(true);
		$duration = $end_time - $start_time;
		echo "$message: " . number_format($duration, 4) . " seconds<br>";
	}

	$start_time = microtime(true);

    $dataPoints1 = $graph->getSoftwareFromTo($conn, $user, $table, $selectedSoftware, $fromDate, $toDate);
	printDuration($start_time, 'Time after getting dp1');
    //$dataPoints2 = $graph->getFeaturePerSoftware($conn, $user, $table, $selectedSoftware, $fromDate, $toDate);
	//printDuration($start_time, 'Time after getting dp2');
    $dataPoints2 = $graph->getSoftwareLicenseCount($conn, $user, $table, $selectedSoftware, $fromDate, $toDate); //->not changed
	printDuration($start_time, 'Time after getting dp3');
	$licenseCount = $graph->getLicenseCount($conn, $user, $table,$selectedSoftware,$fromDate,$toDate);
	printDuration($start_time, 'Time after getting license count');
	//$serverCount = $graph->getServerCount($conn, $user, $table,$selectedSoftware,$fromDate,$toDate);
	//printDuration($start_time, 'Time after getting server count');
	$userCount = $graph->getUserCount($conn, $user, $table,$selectedSoftware,$fromDate,$toDate);
	printDuration($start_time, 'Time after getting user count');
	//$softwareCount = $graph->getSoftwareCount($conn, $user, $table,$selectedSoftware,$fromDate,$toDate);
	//printDuration($start_time, 'Time after getting software count');
	$featureCount = $graph->getFeatureCount($conn, $user, $table,$selectedSoftware);
	printDuration($start_time, 'Time after getting feature count');
	
	
	array_unshift($dataPoints2, ['software' => $selectedSoftware, 'no_licenses' => $licenseCount]);
	$labels = [];
	$largeValues = [];
	$smallValues = [];

	$threshold = 1000000; // Define a threshold to separate large and small values

	foreach ($dataPoints2 as $dataPoint) {
		$labels[] = $dataPoint['software'];
		if ($dataPoint['no_licenses'] > $threshold) {
			$largeValues[] = $dataPoint['no_licenses'];
			$smallValues[] = null; // Ensure the same length of arrays
		} else {
			$smallValues[] = $dataPoint['no_licenses'];
			$largeValues[] = null; // Ensure the same length of arrays
		}
	}

	// Convert PHP arrays to JSON for use in JavaScript
	$labelsJson = json_encode($labels);
	$largeValuesJson = json_encode($largeValues);
	$smallValuesJson = json_encode($smallValues);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($selectedSoftware) ?></title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: #f2f2f2;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            text-align: center;
            width: 65%;
            margin: auto;
        }
        .container h1, .container h2 {
            margin-bottom: 20px;
            color: #333;
        }
        .error {
            color: red;
            font-size: 14px;
            margin-bottom: 10px;
        }
        .button {
            padding: 10px 20px;
            font-size: 16px;
            background: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
        }
        .button:hover {
            background: #0056b3;
        }
        .chartContainer {
            margin-top: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 100%;
            max-height: 500px; /* Adjust height as needed */
			min-height: 500px;
        }
				
				
		.grid-container {
		  display: grid;
		  grid-template-columns: repeat(2, 1fr);
		  gap: 20px;
		}

		.primary-stats {
		  display: flex;
		  flex-direction: column;
		  gap: 20px;
		  color: rgba(86, 94, 88, 1);
		  padding: 5% 5% 0px 5%;
		}


		.big-card, .small-card {
		  background-color: #FFFFFF;
		  display: flex;
		  flex-direction: column;
		  align-items: center;
		  border-radius: 10px;
		  padding: 20px;
		  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
		  transition: transform 0.3s, box-shadow 0.3s;
		}

		.big-card:hover, .small-card:hover {
		  transform: translateY(-10px);
		  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
		}

		.big-card h2, .small-card h3 {
		  font-size: 24px;
		  margin: 10px 0;
		  color: #568E88;
		}

		.big-card h1, .small-card h2 {
		  font-size: 36px;
		  margin: 10px 0;
		  color: #365C54;
		}


		.big-card:hover h2, .small-card:hover h3 {
		  color: #76A79F;
		}

		.big-card:hover h1, .small-card:hover h2 {
		  color: #477873;
		}

		.small-card {
		  padding: 15px;
		}

		@media (max-width: 768px) {
		  
		  .grid-container {
			grid-template-columns: 1fr;
			gap: 10px;
		  }
		  
		  .flex {
			padding: 5%;
		  }
		  
		  .big-card h2, .small-card h3 {
			font-size: 20px;
		  }
		  
		  .big-card h1, .small-card h2 {
			font-size: 28px;
		  }
		}
		
		.chart-container {
            position: relative;
            width: 100%;
            margin-top: 20px; /* Adjust vertical spacing */
        }
		
		.download-button {
            position: absolute;
            bottom: 0; /* Align to bottom */
            right: 0; /* Align to right */
            background-color: #ccc; /* Light gray background for the button */
            color: #333; /* Darker gray text color */
            border: none;
            padding: 10px 15px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 14px;
            transition: background-color 0.3s ease;
        }

        .download-button:hover {
            background-color: #bbb; /* Slightly darker gray on hover */
        }
		
		.download-icon {
            width: 1em; /* Adjust size as needed */
            height: 1em;
            fill: currentColor; /* Use button's text color */
            margin-right: 5px; /* Space between icon and text */
            vertical-align: middle; /* Align vertically */
        }

    </style>
</head>
<body>
    <div class="container">
        <?php if (!empty($selectedSoftware)) : ?>
            <h1><?php echo htmlspecialchars($selectedSoftware) ?>'s Analysis</h1>
            
            <?php if (!empty($error)) : ?>
                <div class="error"><?php echo $error; ?></div>
                <a href="index.php" class="button">Go Back to Index</a>
            <?php else : ?>
                <p>Date range: <?php echo htmlspecialchars($fromDate) ?> to <?php echo htmlspecialchars($toDate) ?></p>
				
				<div class="primary-stats" >
					<div class="big-card">
						<h2>No. of Licenses Issued</h2>
						<h1><?php echo $licenseCount ?></h1>
					</div>
					<div class="grid-container">
						<div class="small-card">
							<h3>Users</h3>
							<h2><?php echo $userCount ?></h2>
						</div>
						<div class="small-card">
							<h3>Features</h3>
							<h2><?php echo $featureCount ?></h2>
						</div>
					</div>
				</div>
					
                <!-- Canvas containers for charts -->
				<div class="chart-container">
					<canvas id="chartContainer1" class="chartContainer"></canvas>
					<button class="download-button" onclick="downloadChart('chartContainer1')">
						<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-download" viewBox="0 0 16 16">
						  <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5"/>
						  <path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708z"/>
						</svg>
					</button>
				</div>
				<div class="chart-container">
					<canvas id="chartContainer2" class="chartContainer"></canvas>
					<button class="download-button" onclick="downloadChart('chartContainer2')">
						<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-download" viewBox="0 0 16 16">
						  <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5"/>
						  <path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708z"/>
						</svg>
					</button>
				</div>
                
                
         
                <!-- Option to explore further -->
                <a href="feature.php?software=<?php echo urlencode($selectedSoftware); ?>&from_date=<?php echo urlencode($fromDate); ?>&to_date=<?php echo urlencode($toDate); ?>" class="button">Explore It's Feature</a>
            <?php endif; ?>
        <?php else : ?>
            <h1>Error</h1>
            <p><?php echo $error; ?></p>
            <a href="index.php" class="button">Go Back to Index</a>
        <?php endif; ?>
    </div>
    <script>
		function downloadChart(chartId) {
			console.log(chartId);
			var canvas = document.getElementById(chartId);
			var link = document.createElement('a');
			link.href = canvas.toDataURL('image/png');
			link.download = 'chart.png';
			document.body.appendChild(link);
			link.click();
			document.body.removeChild(link);
		}
        window.onload = function() {
            var ctx1 = document.getElementById('chartContainer1').getContext('2d');
            var chart1 = new Chart(ctx1, {
                type: 'line',
                data: {
                    labels: <?php echo json_encode(array_column($dataPoints1, 'date')); ?>,
                    datasets: [{
                        label: '<?php echo htmlspecialchars($selectedSoftware); ?>'+"'s "+"Average License Usage",
                        data: <?php echo json_encode(array_column($dataPoints1, 'avg_licenses')); ?>,
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: false,
                            title: {
                                display: true,
                                text: 'Average Licenses Issued',
                                font: {
                                    size: 16, 
                                    family: 'Arial', 
                                    style: 'normal',
                                    lineHeight: 1.2
                                },
                                color: '#000', 
                                padding: {top: 10, left: 0, right: 0, bottom: 10}
                            }
                        },
                        x: {
                            title: {
                                display: true,
                                text: 'Date',
                                font: {
                                    size: 16, 
                                    family: 'Arial', 
                                    style: 'normal',
                                    lineHeight: 1.2
                                },
                                color: '#000', 
                                padding: {top: 10, left: 0, right: 0, bottom: 10}
                            }
                        }
                    },
                    plugins: {
                        title: {
                            display: true,
                            text: 'Average No. of ' + '<?php echo htmlspecialchars($selectedSoftware); ?>'+ ' Licenses Issued',
                            padding: {
                                top: 10,
                                bottom: 10
                            },
                            font: {
                                size: 50
                            }
                        },
                        tooltip: {
                            mode: 'index',
                            intersect: false
                        },
                        interaction: {
                            mode: 'index', 
                            intersect: false 
                        },
                    }
                }
            });
            var ctx2 = document.getElementById('chartContainer2').getContext('2d');
			var labels = <?php echo $labelsJson; ?>;
			var largeData = <?php echo $largeValuesJson; ?>;
			var smallData = <?php echo $smallValuesJson; ?>;
			
			var backgroundColors = [];
			var borderColors = [];
			
			
			for (var i = 0; i < labels.length; i++) {
				if (i === 0) {
					backgroundColors.push('rgba(255, 99, 132, 0.2)');
					borderColors.push('rgba(255, 99, 132, 1)');
				} else {
					backgroundColors.push('rgba(54, 162, 235, 0.2)');
					borderColors.push('rgba(54, 162, 235, 1)');
				}
			}
			
			var chart2 = new Chart(ctx2, {
				type: 'bar',
				data: {
					labels: labels,
					datasets: [
						{
							label: 'Large License Count',
							data: largeData,
							backgroundColor: backgroundColors,
							borderColor: borderColors,
							borderWidth: 1,
							yAxisID: 'yLarge'
						},
						{
							label: 'Small License Count',
							data: smallData,
							backgroundColor: backgroundColors,
							borderColor: borderColors,
							borderWidth: 1,
							yAxisID: 'ySmall'
						}
					]
				},
				options: {
					plugins: {
						datalabels: {
							anchor: 'end',
							align: 'top',
							formatter: function(value, context) {
								return value !== null ? value.toLocaleString() : ''; // Formatting numbers with commas
							}
						},
						legend: {
							display: false
						},
						title: {
                            display: true,
                            text: '<?php echo htmlspecialchars($selectedSoftware); ?>'+ ' vs Other Software',
                            padding: {
                                top: 10,
                                bottom: 10
                            },
                            font: {
                                size: 50
                            }
                        }
					},
					scales: {
						yLarge: {
							beginAtZero: true,
							type: 'linear',
							position: 'left',
							ticks: {
								callback: function(value) {
									return value.toLocaleString(); // Formatting numbers with commas
								}
							},
							title: {
                                display: true,
                                text: 'Large Values',
                                font: {
                                    size: 16, 
                                    family: 'Arial', 
                                    style: 'normal',
                                    lineHeight: 1.2
                                },
                                color: '#000', 
                                padding: {top: 10, left: 0, right: 0, bottom: 10}
                            }
						},
						ySmall: {
							beginAtZero: true,
							type: 'linear',
							position: 'right',
							ticks: {
								callback: function(value) {
									return value.toLocaleString();
								}
							},
							grid: {
								drawOnChartArea: false 
							},
							title: {
                                display: true,
                                text: 'Small Values',
                                font: {
                                    size: 16, 
                                    family: 'Arial', 
                                    style: 'normal',
                                    lineHeight: 1.2
                                },
                                color: '#000', 
                                padding: {top: 10, left: 0, right: 0, bottom: 10}
                            }
						},
						x: {
							title: {
                                display: true,
                                text: 'Software',
                                font: {
                                    size: 16, 
                                    family: 'Arial', 
                                    style: 'normal',
                                    lineHeight: 1.2
                                },
                                color: '#000', 
                                padding: {top: 10, left: 0, right: 0, bottom: 10}
                            }
						}
					}
				}
			});
        }
    </script>
</body>
</html>




