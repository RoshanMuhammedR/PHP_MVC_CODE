<?php
$error = '';
$selectedSoftware = ''; // Initialize $selectedSoftware

if (isset($_GET['software']) && isset($_GET['from_date']) && isset($_GET['to_date'])) {
    $selectedSoftware = $_GET['software'];
    $fromDate = $_GET['from_date'];
    $toDate = $_GET['to_date'];
} else {
    $error = 'Invalid request. Please go back and fill out the form.';
}

include("src/Model/User.php");
include("view/Graph.php");
$table = "licenseuserhistory_correct2";
$user = new User;
$graph = new Graph;
$conn = $user->getConnection("localhost", "hpc", "root", "");


function printDuration($start_time, $message) {
	$end_time = microtime(true);
	$duration = $end_time - $start_time;
	echo "$message: " . number_format($duration, 4) . " seconds<br>";
}

$start_time = microtime(true);

$dataPoints6 = $graph->getUserPerSoftware($conn, $user, $table, $selectedSoftware, $fromDate, $toDate);
printDuration($start_time, 'Time after getting user per software from to count');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($selectedSoftware) ?>'s Feature Analysis</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/moment@2.29.1/min/moment.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-moment"></script>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: #f2f2f2;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            text-align: center;
            width: 65%;
            margin: auto;
        }
        .container h1, .container h2 {
            margin-bottom: 20px;
            color: #333;
        }
        .error {
            color: red;
            font-size: 14px;
            margin-bottom: 10px;
        }
        .button {
            padding: 10px 20px;
            font-size: 16px;
            background: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
        }
        .button:hover {
            background: #0056b3;
        }
        .chartContainer {
            margin-top: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 100%;
            max-height: 500px; /* Adjust height as needed */
			min-height: 500px;
        }
		
		.chart-container {
            position: relative;
            width: 100%;
            margin-top: 20px; /* Adjust vertical spacing */
        }
		
		.download-button {
            position: absolute;
            bottom: 0; /* Align to bottom */
            right: 0; /* Align to right */
            background-color: #ccc; /* Light gray background for the button */
            color: #333; /* Darker gray text color */
            border: none;
            padding: 10px 15px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 14px;
            transition: background-color 0.3s ease;
        }

        .download-button:hover {
            background-color: #bbb; /* Slightly darker gray on hover */
        }
		
		.download-icon {
            width: 1em; /* Adjust size as needed */
            height: 1em;
            fill: currentColor; /* Use button's text color */
            margin-right: 5px; /* Space between icon and text */
            vertical-align: middle; /* Align vertically */
        }
    </style>
</head>
<body>
    <div class="container">
        <?php if (!empty($selectedSoftware)) : ?>
            <h1><?php echo htmlspecialchars($selectedSoftware) ?>'s User Analysis</h1>
            
            <?php if (!empty($error)) : ?>
                <div class="error"><?php echo $error; ?></div>
                <a href="index.php" class="button">Go Back to Index</a>
            <?php else : ?>
                <p>Date range: <?php echo htmlspecialchars($fromDate) ?> to <?php echo htmlspecialchars($toDate) ?></p>
                
                <!-- Canvas containers for charts -->
				<div class="chart-container">
					<canvas id="chartContainer6" class="chartContainer"></canvas>
					<button class="download-button" onclick="downloadChart('chartContainer5')">
						<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-download" viewBox="0 0 16 16">
						  <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5"/>
						  <path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708z"/>
						</svg>
					</button>
				</div>

            <?php endif; ?>
        <?php else : ?>
            <h1>Error</h1>
            <p><?php echo $error; ?></p>
            <a href="index.php" class="button">Go Back to Index</a>
        <?php endif; ?>
    </div>
    <script>
        var datasets6= [];
        <?php foreach ($dataPoints6 as $username => $data) : ?>
            datasets6.push({
                label: '<?php echo htmlspecialchars($username); ?>',
                data: <?php echo json_encode(array_map(function($entry) {
                    return ['x' => $entry['date'], 'y' => $entry['avg_licenses']];
                }, $data)); ?>,
                borderWidth: 1,
                fill: false,
                spanGaps: false
            });
        <?php endforeach; ?>
       thod
	   

        var ctx6 = document.getElementById('chartContainer6').getContext('2d');
        var chart6 = new Chart(ctx6, {
            type: 'line',
            data: {
                datasets: datasets6
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        type: 'time',
                        time: {
                            unit: 'day'
                        },
                        title: {
                            display: true,
                            text: 'Date',
                            font: {
                                size: 16,
                                family: 'Arial',
                                style: 'normal',
                                lineHeight: 1.2
                            },
                            color: '#000',
                            padding: { top: 10, left: 0, right: 0, bottom: 10 }
                        }
                    },
                    y: {
                        beginAtZero: false,
                        title: {
                            display: true,
                            text: 'Average Licenses Issued',
                            font: {
                                size: 16,
                                family: 'Arial',
                                style: 'normal',
                                lineHeight: 1.2
                            },
                            color: '#000',
                            padding: { top: 10, left: 0, right: 0, bottom: 10 }
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        mode: 'index',
                        intersect: false
                    },
                    interaction: {
                        mode: 'index',
                        intersect: false
                    },
                    title: {
                        display: true,
                        text: 'Average Number of Licenses Issued for <?php echo htmlspecialchars($selectedSoftware); ?> by User',
                        padding: {
                            top: 10,
                            bottom: 10
                        },
                        font: {
                            size: 20
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>
