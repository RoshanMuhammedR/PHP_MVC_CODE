<?php
    $error = '';
    $selectedSoftware = ''; // Initialize $selectedSoftware

    if (isset($_GET['software']) && isset($_GET['from_date']) && isset($_GET['to_date'])) {
        $selectedSoftware = $_GET['software'];
        $fromDate = $_GET['from_date'];
        $toDate = $_GET['to_date'];
    } else {
        $error = 'Invalid request. Please go back and fill out the form.';
    }

    include("src/Model/User.php");
    include("view/Graph.php");
    $table = "licenseuserhistory_correct2";
    $user = new User;
    $graph = new Graph;
    $conn = $user->getConnection("localhost", "hpc", "root", "");
	
	
	function printDuration($start_time, $message) {
		$end_time = microtime(true);
		$duration = $end_time - $start_time;
		echo "$message: " . number_format($duration, 4) . " seconds<br>";
	}

	$start_time = microtime(true);

    $dataPoints3 = $graph->getFeatureFromTo($conn, $user, $table, $selectedSoftware, $fromDate, $toDate);
	printDuration($start_time, 'Time after getting feature from to count');
    $dataPoints4 = $graph->getUserPerFeature($conn, $user, $table, $selectedSoftware, $fromDate, $toDate);
	printDuration($start_time, 'Time after getting User per feature count');
    $dataPoints5 = $graph->getFeatureStats($conn, $user, $table, $selectedSoftware, $fromDate, $toDate);
	printDuration($start_time, 'Time after getting feature stats count');


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($selectedSoftware) ?>'s Feature Analysis</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-moment"></script>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: #f2f2f2;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            text-align: center;
            width: 65%;
            margin: auto;
        }
        .container h1, .container h2 {
            margin-bottom: 20px;
            color: #333;
        }
        .error {
            color: red;
            font-size: 14px;
            margin-bottom: 10px;
        }
        .button {
            padding: 10px 20px;
            font-size: 16px;
            background: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
        }
        .button:hover {
            background: #0056b3;
        }
        .chartContainer {
            margin-top: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 100%;
            max-height: 500px; /* Adjust height as needed */
			min-height:500px;
        }
		
		.chart-container {
            position: relative;
            width: 100%;
            margin-top: 20px; /* Adjust vertical spacing */
        }
		
		.download-button {
            position: absolute;
            bottom: 0; /* Align to bottom */
            right: 0; /* Align to right */
            background-color: #ccc; /* Light gray background for the button */
            color: #333; /* Darker gray text color */
            border: none;
            padding: 10px 15px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 14px;
            transition: background-color 0.3s ease;
        }

        .download-button:hover {
            background-color: #bbb; /* Slightly darker gray on hover */
        }
		
		.download-icon {
            width: 1em; /* Adjust size as needed */
            height: 1em;
            fill: currentColor; /* Use button's text color */
            margin-right: 5px; /* Space between icon and text */
            vertical-align: middle; /* Align vertically */
        }
    </style>
</head>
<body>
    <div class="container">
        <?php if (!empty($selectedSoftware)) : ?>
            <h1><?php echo htmlspecialchars($selectedSoftware) ?>'s Feature Analysis</h1>
            
            <?php if (!empty($error)) : ?>
                <div class="error"><?php echo $error; ?></div>
                <a href="index.php" class="button">Go Back to Index</a>
            <?php else : ?>
                <p>Date range: <?php echo htmlspecialchars($fromDate) ?> to <?php echo htmlspecialchars($toDate) ?></p>
                
                <!-- Canvas containers for charts -->
				<div class="chart-container">
					<canvas id="chartContainer3" class="chartContainer"></canvas>
					<button class="download-button" onclick="downloadChart('chartContainer3')">
						<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-download" viewBox="0 0 16 16">
						  <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5"/>
						  <path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708z"/>
						</svg>
					</button>
				</div>
				<div class="chart-container">
					<canvas id="chartContainer4" class="chartContainer"></canvas>
					<button class="download-button" onclick="downloadChart('chartContainer4')">
						<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-download" viewBox="0 0 16 16">
						  <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5"/>
						  <path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708z"/>
						</svg>
					</button>
				</div>
				<div class="chart-container">
					<canvas id="chartContainer5" class="chartContainer"></canvas>
					<button class="download-button" onclick="downloadChart('chartContainer5')">
						<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-download" viewBox="0 0 16 16">
						  <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5"/>
						  <path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708z"/>
						</svg>
					</button>
				</div>
    
                <a href="user.php?software=<?php echo urlencode($selectedSoftware); ?>&from_date=<?php echo urlencode($fromDate); ?>&to_date=<?php echo urlencode($toDate); ?>" class="button">Explore It's Users</a>
            <?php endif; ?>
        <?php else : ?>
            <h1>Error</h1>
            <p><?php echo $error; ?></p>
            <a href="index.php" class="button">Go Back to Index</a>
        <?php endif; ?>
    </div>
    <script>
		function downloadChart(chartId) {
			console.log(chartId);
			var canvas = document.getElementById(chartId);
			var link = document.createElement('a');
			link.href = canvas.toDataURL('image/png');
			link.download = 'chart.png';
			document.body.appendChild(link);
			link.click();
			document.body.removeChild(link);
		}
        window.onload = function() {
            var datasets3 = [];
            <?php foreach ($dataPoints3 as $feature => $data) : ?>
                datasets3.push({
                    label: '<?php echo htmlspecialchars($feature); ?>',
                    data: <?php echo json_encode(array_map(function($entry) {
                        return ['x' => $entry['date'], 'y' => $entry['avg_licenses']];
                    }, $data)); ?>,
                    borderWidth: 1,
                    fill: false,
                    spanGaps: true, // Ensure gaps are handled
                });
            <?php endforeach; ?>

            var ctx3 = document.getElementById('chartContainer3').getContext('2d');
            var chart3 = new Chart(ctx3, {
                type: 'line',
                data: {
                    datasets: datasets3
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: false,
                            title: {
                                display: true,
                                text: 'Average License Issued',
                                font: {
                                    size: 16,
                                    family: 'Arial',
                                    style: 'normal',
                                    lineHeight: 1.2
                                },
                                color: '#000',
                                padding: { top: 10, left: 0, right: 0, bottom: 10 }
                            }
                        },
                        x: {
                            type: 'time',
                            time: {
                                unit: 'day', // Adjust based on your data density
                                tooltipFormat: 'll',
                                displayFormats: {
                                    day: 'MMM D',
                                }
                            },
                            title: {
                                display: true,
                                text: 'Date',
                                font: {
                                    size: 16,
                                    family: 'Arial',
                                    style: 'normal',
                                    lineHeight: 1.2
                                },
                                color: '#000',
                                padding: { top: 10, left: 0, right: 0, bottom: 10 }
                            }
                        }
                    },
                    plugins: {
                        tooltip: {
                            mode: 'index',
                            intersect: false
                        },
                        interaction: {
                            mode: 'index',
                            intersect: false
                        },
                        title: {
                            display: true,
                            text: 'Average Number of Licenses Issued for <?php echo htmlspecialchars($selectedSoftware); ?> Features',
                            padding: {
                                top: 10,
                                bottom: 10
                            },
                            font: {
                                size: 20
                            }
                        }
                    }
                }
            });


            var datasets4 = [];
            <?php foreach ($dataPoints4 as $feature => $data) : ?>
                datasets4.push({
                    label: '<?php echo htmlspecialchars($feature); ?>',
                    data: <?php echo json_encode(array_map(function($entry) {
                        return ['x' => $entry['date'], 'y' => $entry['user_count']];
                    }, $data)); ?>,
                    borderWidth: 1,
                    fill: false,
                    spanGaps: true, // Adjusted to handle gaps
                    pointBackgroundColor: 'rgba(75, 192, 192, 0.6)',
                    pointBorderColor: 'rgba(75, 192, 192, 1)',
                    pointBorderWidth: 1,
                    pointRadius: 2,
                });
            <?php endforeach; ?>

            var ctx4 = document.getElementById('chartContainer4').getContext('2d');
            var chart4 = new Chart(ctx4, {
                type: 'line',
                data: {
                    datasets: datasets4
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Number of Users',
                                font: {
                                    size: 16,
                                    family: 'Arial',
                                    style: 'normal',
                                    lineHeight: 1.2
                                },
                                color: '#000',
                                padding: {top: 10, left: 0, right: 0, bottom: 10}
                            }
                        },
                        x: {
                            type: 'time', // Adjusted to handle dates as time series
                            time: {
                                unit: 'day', // Adjust based on your data density
                                tooltipFormat: 'll',
                                displayFormats: {
                                    day: 'MMM D',
                                }
                            },
                            title: {
                                display: true,
                                text: 'Date',
                                font: {
                                    size: 16,
                                    family: 'Arial',
                                    style: 'normal',
                                    lineHeight: 1.2
                                },
                                color: '#000',
                                padding: {top: 10, left: 0, right: 0, bottom: 10}
                            }
                        }
                    },
                    plugins: {
                        tooltip: {
                            mode: 'index',
                            intersect: false,
                            callbacks: {
                                label: function(context) {
                                    var users = <?php echo json_encode(array_map(function($data) { return $data['users']; }, $dataPoints4[$feature])); ?>;
                                    return context.raw.y + ': ' + users[context.dataIndex];
                                }
                            }
                        },
                        interaction: {
                            mode: 'index',
                            intersect: false
                        },
                        title: {
                            display: true,
                            text: 'Number of <?php echo htmlspecialchars($selectedSoftware); ?> Users per Feature',
                            padding: {
                                top: 10,
                                bottom: 10
                            },
                            font: {
                                size: 20
                            }
                        }
                    }
                }
            });


            var ctx5 = document.getElementById('chartContainer5').getContext('2d');
            var chart5 = new Chart(ctx5, {
                type: 'pie',
                data: {
                    labels: <?php echo json_encode(array_column($dataPoints5, 'feature')); ?>,
                    datasets: [{
                        label: 'Licenses Issued per Feature',
                        data: <?php echo json_encode(array_column($dataPoints5, 'no_licenses')); ?>,
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        title: {
                            display: true,
                            text: 'Licenses Issued per Feature for <?php echo htmlspecialchars($selectedSoftware); ?>',
                            padding: {
                                top: 10,
                                bottom: 10
                            },
                            font: {
                                size: 20
                            }
                        }
                    }
                }
            });



        
        }
    </script>
</body>
</html>
