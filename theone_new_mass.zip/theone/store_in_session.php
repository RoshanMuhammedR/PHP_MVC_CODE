<?php
session_start();

$postData = file_get_contents("php://input");
$request = json_decode($postData, true);

if (isset($request['dataPoints'])) {
    $_SESSION['dataPoints'] = $request['dataPoints'];
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'No dataPoints received']);
}
?>
