<?php
    session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sample Table to CSV</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.16.2/xlsx.full.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        .table-container {
            width: 80%;
            max-height: 400px;
            margin: 20px auto;
            overflow-y: auto;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 8px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #ddd;
        }
        .button-container {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin: 20px auto;
        }
        button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

<h2>Sample Table</h2>

<div class="table-container">
    <table id="sampleTable">
        <tr>
            <!-- PHP dynamic headings -->
            <?php
            if (isset($_SESSION['dataPoints']) && !empty($_SESSION['dataPoints'])) {
                $headings = array_keys($_SESSION['dataPoints'][0]);
                foreach ($headings as $heading) {
                    echo "<th>$heading</th>";
                }
            }
            ?>
        </tr>
        <!-- PHP dynamic data rows -->
        <?php
        if (isset($_SESSION['dataPoints']) && !empty($_SESSION['dataPoints'])) {
            foreach ($_SESSION['dataPoints'] as $row) {
                echo "<tr>";
                foreach ($row as $value) {
                    echo "<td>$value</td>";
                }
                echo "</tr>";
            }
        }
        ?>
    </table>
</div>

<div class="button-container">
    <button onclick="exportTableToCSV('sample_table.csv')">Export Table to CSV</button>
    <button onclick="goBack()">Go Back</button>
</div>

<script>
function exportTableToCSV(filename) {
    var table = document.getElementById("sampleTable");
    var workbook = XLSX.utils.table_to_book(table, {sheet: "Sheet1"});
    XLSX.writeFile(workbook, filename);
}

function goBack() {
    window.history.back();
}
</script>

</body>
</html>
