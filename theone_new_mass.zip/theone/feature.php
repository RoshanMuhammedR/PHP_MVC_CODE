<?php

    $error = '';
    $selectedSoftware = ''; // Initialize $selectedSoftware

    if (isset($_GET['software']) && isset($_GET['from_date']) && isset($_GET['to_date'])) {
        $selectedSoftware = $_GET['software'];
        $fromDate = $_GET['from_date'];
        $toDate = $_GET['to_date'];
    } else {
        $error = 'Invalid request. Please go back and fill out the form.';
    }
    session_start();

    include("src/Model/User.php");
    include("view/Graph.php");
    $table = "licenseuserhistory_correct2";
    $user = new User;
    $graph = new Graph;
    $conn = $user->getConnection("localhost", "hpc", "root", "");
	
	
	function printDuration($start_time, $message) {
		$end_time = microtime(true);
		$duration = $end_time - $start_time;
		echo "$message: " . number_format($duration, 4) . " seconds<br>";
	}

	$start_time = microtime(true);

    
    $dataPoints4 = $graph->getUserPerFeature($conn, $user, $table, $selectedSoftware, $fromDate, $toDate);
	//printDuration($start_time, 'Time after getting User per feature count');
    
    $dataPoints6 = $graph->getUserPerSoftware($conn, $user, $table, $selectedSoftware, $fromDate, $toDate);
    //printDuration($start_time, 'Time after getting user per software from to count');

    $dataPoints2 = $graph->getSoftwareLicenseCount($conn, $user, $table, $selectedSoftware, $fromDate, $toDate); //->not changed
	//printDuration($start_time, 'Time after getting dp3');

    $licenseCount = $graph->getLicenseCount($conn, $user, $table,$selectedSoftware,$fromDate,$toDate);
	//printDuration($start_time, 'Time after getting license count');

    array_unshift($dataPoints2, ['software' => $selectedSoftware, 'no_licenses' => $licenseCount]);
	$labels = [];
	$largeValues = [];
	$smallValues = [];

	$threshold = 1000000; // Define a threshold to separate large and small values

	foreach ($dataPoints2 as $dataPoint) {
		$labels[] = $dataPoint['software'];
		if ($dataPoint['no_licenses'] > $threshold) {
			$largeValues[] = $dataPoint['no_licenses'];
			$smallValues[] = null; // Ensure the same length of arrays
		} else {
			$smallValues[] = $dataPoint['no_licenses'];
			$largeValues[] = null; // Ensure the same length of arrays
		}
	}

	// Convert PHP arrays to JSON for use in JavaScript
	$labelsJson = json_encode($labels);
	$largeValuesJson = json_encode($largeValues);
	$smallValuesJson = json_encode($smallValues);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($selectedSoftware) ?>'s Feature Analysis</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-moment"></script>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: #f2f2f2;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            text-align: center;
            width: 65%;
            margin: auto;
        }
        .container h1, .container h2 {
            margin-bottom: 20px;
            color: #333;
        }
        .error {
            color: red;
            font-size: 14px;
            margin-bottom: 10px;
        }
        .button {
            padding: 10px 20px;
            font-size: 16px;
            background: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
        }
        .button:hover {
            background: #0056b3;
        }
        .chartContainer {
            margin-top: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 100%;
            max-height: 500px; 
			min-height:500px;
        }
		
		.chart-container {
            position: relative;
            width: 100%;
            margin-top: 20px; 
        }
		
		.download-button {
            position: absolute;
            bottom: 0; 
            right: 0; 
            background-color: #ccc; 
            color: #333; 
            border: none;
            padding: 10px 15px;
            cursor: pointer;
            border-top-left-radius: 5px; 
            border-top-right-radius: 0; 
            border-bottom-right-radius: 5px; 
            border-bottom-left-radius: 0;
            font-size: 14px;
            transition: background-color 0.3s ease;
        }

        .download-button:hover {
            background-color: #bbb; 
        }
		
		.download-icon {
            width: 1em; 
            height: 1em;
            fill: currentColor; 
            margin-right: 5px; 
            vertical-align: middle; 
        }

        .custom-button {
        background-color: #007bff; 
        color: #fff; 
        padding: 10px 20px; 
        border: none; 
        border-top-left-radius: 0; 
        border-top-right-radius: 5px; 
        border-bottom-right-radius: 0; 
        border-bottom-left-radius: 5px;
        cursor: pointer; 
        transition: background-color 0.3s; 
        }

        .custom-button:hover {
            background-color: #0056b3; 
        }

        .bottom-right-button {
            position: absolute; 
            bottom: 0; 
            left: 0; 
        }

       
        .custom-button {
            font-size: 16px; 
        }
		
		.header{
			background-color: #568E88;
			height:100px;
			display: flex;
			align-items: center; 
			justify-content: center;
			border-radius:8px;
		}
    </style>
</head>
<body>
    <div class="container">
        <?php if (!empty($selectedSoftware)) : ?>
            <div class="header">
				<h1><?php echo htmlspecialchars($selectedSoftware) ?>'s Analysis</h1>
			</div>
            
            <?php if (!empty($error)) : ?>
                <div class="error"><?php echo $error; ?></div>
                <a href="index.php" class="button">Go Back to Index</a>
            <?php else : ?>
                <p>Date range: <?php echo htmlspecialchars($fromDate) ?> to <?php echo htmlspecialchars($toDate) ?></p>
                
                <!-- Canvas containers for charts -->
				
				<div class="chart-container">
					<canvas id="chartContainer4" class="chartContainer"></canvas>
					<button class="download-button" onclick="downloadChart('chartContainer4')">
						<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-download" viewBox="0 0 16 16">
						  <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5"/>
						  <path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708z"/>
						</svg>
					</button>
                    <button class="custom-button bottom-right-button" onclick="toTableView4()">
                    View Table
                    </button>
				</div>

                <div class="chart-container">
					<canvas id="chartContainer6" class="chartContainer"></canvas>
					<button class="download-button" onclick="downloadChart('chartContainer6')">
						<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-download" viewBox="0 0 16 16">
						  <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5"/>
						  <path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708z"/>
						</svg>
					</button>
                    <button class="custom-button bottom-right-button" onclick="toTableView6()">
                    View Table
                    </button>
				</div>

                <div class="chart-container">
					<canvas id="chartContainer2" class="chartContainer"></canvas>
					<button class="download-button" onclick="downloadChart('chartContainer2')">
						<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-download" viewBox="0 0 16 16">
						  <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5"/>
						  <path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708z"/>
						</svg>
					</button>
                    <button class="custom-button bottom-right-button" onclick="toTableView2()">
                    View Table
                    </button>
				</div>
				
    
        
            <?php endif; ?>
        <?php else : ?>
            <h1>Error</h1>
            <p><?php echo $error; ?></p>
            <a href="index.php" class="button">Go Back to Index</a>
        <?php endif; ?>
    </div>
    <script>
	
		function toTableView4() {
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "store_in_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");

            var data = {
                dataPoints: <?php echo json_encode($dataPoints4); ?>
            };

            xhr.send(JSON.stringify(data));

            xhr.onreadystatechange = function () {
                if (xhr.readyState === XMLHttpRequest.DONE) {
                    if (xhr.status === 200) {
                        var response = JSON.parse(xhr.responseText);
                        if (response.success) {
                            window.location.href = "tables2.php";
                        } else {
                            console.error("Error storing data in session: " + response.message);
                        }
                    } else {
                        console.error("Error storing data in session");
                    }
                }
            };
        }
		function toTableView6() {
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "store_in_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");

            var data = {
                dataPoints: <?php echo json_encode($dataPoints6); ?>
            };

            xhr.send(JSON.stringify(data));

            xhr.onreadystatechange = function () {
                if (xhr.readyState === XMLHttpRequest.DONE) {
                    if (xhr.status === 200) {
                        var response = JSON.parse(xhr.responseText);
                        if (response.success) {
                            window.location.href = "tables.php";
                        } else {
                            console.error("Error storing data in session: " + response.message);
                        }
                    } else {
                        console.error("Error storing data in session");
                    }
                }
            };
        }
		function toTableView2() {
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "store_in_session.php", true);
            xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");

            var data = {
                dataPoints: <?php echo json_encode($dataPoints2); ?>
            };

            xhr.send(JSON.stringify(data));

            xhr.onreadystatechange = function () {
                if (xhr.readyState === XMLHttpRequest.DONE) {
                    if (xhr.status === 200) {
                        var response = JSON.parse(xhr.responseText);
                        if (response.success) {
                            window.location.href = "table.php";
                        } else {
                            console.error("Error storing data in session: " + response.message);
                        }
                    } else {
                        console.error("Error storing data in session");
                    }
                }
            };
        }
       
		function downloadChart(chartId) {
			console.log(chartId);
			var canvas = document.getElementById(chartId);
			var link = document.createElement('a');
			link.href = canvas.toDataURL('image/png');
			link.download = 'chart.png';
			document.body.appendChild(link);
			link.click();
			document.body.removeChild(link);
		}
        window.onload = function() {
            

            

            function getRandomColor() {
                // Generate a random color with 50% opacity
                var letters = '0123456789ABCDEF';
                var color = 'rgba(';
                for (var i = 0; i < 3; i++) {
                    var part = Math.floor(Math.random() * 256); // RGB values between 0 and 255
                    color += part;
                    if (i < 2) {
                        color += ',';
                    } else {
                        color += ',0.5)'; // Alpha value of 0.5 (50% opacity)
                    }
                }
                return color;
            }


            var datasets4 = [];
            var colorsMap = {};

            <?php foreach ($dataPoints4 as $feature => $data) : ?>
                var color = getRandomColor();
                colorsMap['<?php echo htmlspecialchars($feature); ?>'] = color;
                datasets4.push({
                    label: '<?php echo htmlspecialchars($feature); ?>',
                    data: <?php echo json_encode(array_map(function($entry) {
                        return ['x' => $entry['date'], 'y' => $entry['user_count']];
                    }, $data)); ?>,
                    borderColor: color,
                    backgroundColor: color,
                    borderWidth: 1,
                    fill: false,
                    spanGaps: true,
                    pointBackgroundColor: color,
                    pointBorderColor: color,
                    pointBorderWidth: 1,
                    pointRadius: 2,
                });
            <?php endforeach; ?>

            var ctx4 = document.getElementById('chartContainer4').getContext('2d');
            var chart4 = new Chart(ctx4, {
                type: 'line',
                data: {
                    datasets: datasets4
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Number of Users',
                                font: {
                                    size: 16,
                                    family: 'Arial',
                                    style: 'normal',
                                    lineHeight: 1.2
                                },
                                color: '#000',
                                padding: { top: 10, left: 0, right: 0, bottom: 10 }
                            }
                        },
                        x: {
                            type: 'time',
                            time: {
                                unit: 'day',
                                tooltipFormat: 'll',
                                displayFormats: {
                                    day: 'MMM D',
                                }
                            },
                            title: {
                                display: true,
                                text: 'Date',
                                font: {
                                    size: 16,
                                    family: 'Arial',
                                    style: 'normal',
                                    lineHeight: 1.2
                                },
                                color: '#000',
                                padding: { top: 10, left: 0, right: 0, bottom: 10 }
                            }
                        }
                    },
                    plugins: {
                        tooltip: {
                            mode: 'index',
                            intersect: false,
                            callbacks: {
                                label: function(context) {
                                    var featureName = context.dataset.label;
                                    var dataIndex = context.dataIndex;
                                    var userCount = context.dataset.data[dataIndex].y;
                                    var users = <?php echo json_encode($dataPoints4); ?>[featureName][dataIndex].users;

                                    return userCount + ' users: ' + users;
                                },
                                labelColor: function(context) {
                                    var dataset = context.dataset;
                                    return {
                                        borderColor: dataset.borderColor,
                                        backgroundColor: dataset.borderColor
                                    };
                                }
                            }
                        },
                        interaction: {
                            mode: 'index',
                            intersect: false
                        },
                        title: {
                            display: true,
                            text: 'Number of <?php echo htmlspecialchars($selectedSoftware); ?> Users per Feature',
                            padding: {
                                top: 10,
                                bottom: 10
                            },
                            font: {
                                size: 50
                            }
                        }
                    }
                }
            });

            var datasets6= [];
        <?php foreach ($dataPoints6 as $username => $data) : ?>
            datasets6.push({
                label: '<?php echo htmlspecialchars($username); ?>',
                data: <?php echo json_encode(array_map(function($entry) {
                    return ['x' => $entry['date'], 'y' => $entry['avg_licenses']];
                }, $data)); ?>,
                borderWidth: 1,
                fill: false,
                spanGaps: false
            });
        <?php endforeach; ?>
            
	   

        var ctx6 = document.getElementById('chartContainer6').getContext('2d');
        var chart6 = new Chart(ctx6, {
            type: 'line',
            data: {
                datasets: datasets6
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        type: 'time',
                        time: {
                            unit: 'day'
                        },
                        title: {
                            display: true,
                            text: 'Date',
                            font: {
                                size: 16,
                                family: 'Arial',
                                style: 'normal',
                                lineHeight: 1.2
                            },
                            color: '#000',
                            padding: { top: 10, left: 0, right: 0, bottom: 10 }
                        }
                    },
                    y: {
                        beginAtZero: false,
                        title: {
                            display: true,
                            text: 'Average Licenses Issued',
                            font: {
                                size: 16,
                                family: 'Arial',
                                style: 'normal',
                                lineHeight: 1.2
                            },
                            color: '#000',
                            padding: { top: 10, left: 0, right: 0, bottom: 10 }
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        mode: 'index',
                        intersect: false
                    },
                    interaction: {
                        mode: 'index',
                        intersect: false
                    },
                    title: {
                        display: true,
                        text: 'Average Number of Licenses Issued for <?php echo htmlspecialchars($selectedSoftware); ?> by User',
                        padding: {
                            top: 10,
                            bottom: 10
                        },
                        font: {
                            size: 35
                        }
                    }
                }
            }
        });

            
        var ctx2 = document.getElementById('chartContainer2').getContext('2d');
			var labels = <?php echo $labelsJson; ?>;
			var largeData = <?php echo $largeValuesJson; ?>;
			var smallData = <?php echo $smallValuesJson; ?>;
			
			var backgroundColors = [];
			var borderColors = [];
			
			
			for (var i = 0; i < labels.length; i++) {
				if (i === 0) {
					backgroundColors.push('rgba(255, 99, 132, 0.2)');
					borderColors.push('rgba(255, 99, 132, 1)');
				} else {
					backgroundColors.push('rgba(54, 162, 235, 0.2)');
					borderColors.push('rgba(54, 162, 235, 1)');
				}
			}
			
			var chart2 = new Chart(ctx2, {
				type: 'bar',
				data: {
					labels: labels,
					datasets: [
						{
							label: 'Large License Count',
							data: largeData,
							backgroundColor: backgroundColors,
							borderColor: borderColors,
							borderWidth: 1,
							yAxisID: 'yLarge'
						},
						{
							label: 'Small License Count',
							data: smallData,
							backgroundColor: backgroundColors,
							borderColor: borderColors,
							borderWidth: 1,
							yAxisID: 'ySmall'
						}
					]
				},
				options: {
					plugins: {
						datalabels: {
							anchor: 'end',
							align: 'top',
							formatter: function(value, context) {
								return value !== null ? value.toLocaleString() : ''; // Formatting numbers with commas
							}
						},
						legend: {
							display: false
						},
						title: {
                            display: true,
                            text: '<?php echo htmlspecialchars($selectedSoftware); ?>'+ ' vs Other Software',
                            padding: {
                                top: 10,
                                bottom: 10
                            },
                            font: {
                                size: 50
                            }
                        }
					},
					scales: {
						yLarge: {
							beginAtZero: true,
							type: 'linear',
							position: 'left',
							ticks: {
								callback: function(value) {
									return value.toLocaleString(); // Formatting numbers with commas
								}
							},
							title: {
                                display: true,
                                text: 'Large Values',
                                font: {
                                    size: 16, 
                                    family: 'Arial', 
                                    style: 'normal',
                                    lineHeight: 1.2
                                },
                                color: '#000', 
                                padding: {top: 10, left: 0, right: 0, bottom: 10}
                            }
						},
						ySmall: {
							beginAtZero: true,
							type: 'linear',
							position: 'right',
							ticks: {
								callback: function(value) {
									return value.toLocaleString();
								}
							},
							grid: {
								drawOnChartArea: false 
							},
							title: {
                                display: true,
                                text: 'Small Values',
                                font: {
                                    size: 16, 
                                    family: 'Arial', 
                                    style: 'normal',
                                    lineHeight: 1.2
                                },
                                color: '#000', 
                                padding: {top: 10, left: 0, right: 0, bottom: 10}
                            }
						},
						x: {
							title: {
                                display: true,
                                text: 'Software',
                                font: {
                                    size: 16, 
                                    family: 'Arial', 
                                    style: 'normal',
                                    lineHeight: 1.2
                                },
                                color: '#000', 
                                padding: {top: 10, left: 0, right: 0, bottom: 10}
                            }
						}
					}
				}
			});


        
        }
    </script>
</body>
</html>
