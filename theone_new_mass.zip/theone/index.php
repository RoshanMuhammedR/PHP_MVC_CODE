<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Software Usage Query</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: #f2f2f2;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: #fff;
            padding: 20px 40px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            text-align: center;
            width: 300px;
        }
        .container h2 {
            margin-bottom: 20px;
            color: #333;
        }
        .container form {
            display: flex;
            flex-direction: column;
        }
        .container input {
            margin-bottom: 15px;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .container button {
            padding: 10px;
            font-size: 16px;
            background: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .container button:hover {
            background: #0056b3;
        }
        .error {
            color: red;
            font-size: 14px;
            margin-bottom: 10px;
        }
        .dropdown {
            position: relative;
            display: inline-block;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 230px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
            border-radius: 5px;
            max-height: 150px;
            overflow-y: auto;
        }
        .dropdown-content div {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            cursor: pointer;
        }
        .dropdown-content div:hover {
            background-color: #f1f1f1;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Software Usage Query</h2>
        <?php
        include("src/Model/User.php");
        include("view/Graph.php");
        $table = "licenseuserhistory_correct2";
        $user = new User;
        $graph = new Graph;
        $conn = $user->getConnection("localhost", "hpc", "root", "");

        $dataPoints = $graph->getSoftwares($conn, $user, $table);
        
        
        $softwareList = array_column($dataPoints,'software');

        $error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $selectedSoftware = $_POST['software'];
            $fromDate = $_POST['from_date'];
            $toDate = $_POST['to_date'];

            if (empty($selectedSoftware) || empty($fromDate) || empty($toDate)) {
                $error = 'All fields are required.';
            } elseif (!in_array(strtolower($selectedSoftware), array_map('strtolower', $softwareList))) {
                $error = 'Invalid software name.';
            } elseif (strtotime($fromDate) > strtotime($toDate)) {
                $error = 'Start date must be before end date.';
            } else {
                header('Location: software.php?software=' . urlencode($selectedSoftware) . '&from_date=' . urlencode($fromDate) . '&to_date=' . urlencode($toDate));
                exit();
            }
        }
        ?>
        <form method="post" action="">
            <?php if ($error): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php endif; ?>
            <div class="dropdown">
                <input type="text" id="software" name="software" placeholder="Software Name" required autocomplete="off">
                <div id="dropdown-content" class="dropdown-content">
                    <!-- list items -->
                </div>
            </div>
            <input type="date" name="from_date" placeholder="Start Date" required>
            <input type="date" name="to_date" placeholder="End Date" required>
            <button type="submit">Submit</button>
        </form>
    </div>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const softwareInput = document.getElementById('software');
            const dropdownContent = document.getElementById('dropdown-content');
            const softwareList = <?php echo json_encode($softwareList); ?>;

            softwareInput.addEventListener('input', function() {
                const inputValue = softwareInput.value.toLowerCase();
                dropdownContent.innerHTML = '';
                if (inputValue) {
                    const filteredList = softwareList.filter(item => item.toLowerCase().includes(inputValue));
                    filteredList.forEach(item => {
                        const div = document.createElement('div');
                        div.textContent = item;
                        div.addEventListener('click', function() {
                            softwareInput.value = item;
                            dropdownContent.style.display = 'none';
                        });
                        dropdownContent.appendChild(div);
                    });
                    dropdownContent.style.display = 'block';
                } else {
                    dropdownContent.style.display = 'none';
                }
            });

            document.addEventListener('click', function(event) {
                if (!event.target.closest('.dropdown')) {
                    dropdownContent.style.display = 'none';
                }
            });
        });
    </script>
</body>
</html>
