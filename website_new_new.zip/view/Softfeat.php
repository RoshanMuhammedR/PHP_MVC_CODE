<?php
    $selectedSoftware1 = $_GET['software'];
    $selectedSoftware2 = $_GET['feature'];

    echo "You have selected: <br>";
    echo "Software 1: " . htmlspecialchars($selectedSoftware1) . "<br>";
    echo "Software 2: " . htmlspecialchars($selectedSoftware2);
?>