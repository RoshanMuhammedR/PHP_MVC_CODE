<?php

$dataPoints5 = $graph->getFeatureStats($conn, $user, $table, $selectedSoftware, $fromDate, $toDate);

    

    function getFeatureStats($conn,$user,$table,$software,$from,$to){
        $sql = "SELECT
                    feature,
                    SUM(licenses) AS no_licenses
                FROM `$software`
                WHERE start_time_standardized BETWEEN '$from' AND '$to'
                GROUP BY feature
                ORDER BY SUM(licenses) DESC;
            ";
        $rows = $user->fetchTableData($conn,$sql);
        return $rows;
    }


?>

<canvas id="chartContainer5" class="chartContainer"></canvas>


<script>

    var ctx5 = document.getElementById('chartContainer5').getContext('2d');
            var chart5 = new Chart(ctx5, {
                type: 'pie',
                data: {
                    labels: <?php echo json_encode(array_column($dataPoints5, 'feature')); ?>,
                    datasets: [{
                        label: 'Licenses Issued per Feature',
                        data: <?php echo json_encode(array_column($dataPoints5, 'no_licenses')); ?>,
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });

</script>