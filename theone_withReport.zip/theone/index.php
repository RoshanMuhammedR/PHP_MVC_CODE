<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Software Usage Query</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: #f2f2f2;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: #fff;
            padding: 20px 40px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            text-align: center;
            width: 300px;
        }
        .container h2 {
            margin-bottom: 20px;
            color: #333;
        }
        .container form {
            display: flex;
            flex-direction: column;
        }
        .container select {
            margin-bottom: 15px;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .container button {
            padding: 10px;
            font-size: 16px;
            background: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .container button:hover {
            background: #0056b3;
        }
        .error {
            color: red;
            font-size: 14px;
            margin-bottom: 10px;
        }
        .dropdown {
            position: relative;
            display: inline-block;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 100%;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
            border-radius: 5px;
            max-height: 150px;
            overflow-y: auto;
        }
        .dropdown-content div {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            cursor: pointer;
        }
        .dropdown-content div:hover {
            background-color: #f1f1f1;
        }
		
		.container input[type="date"] {
			margin-bottom: 15px;
			padding: 10px;
			font-size: 16px;
			border: 1px solid #ddd;
			border-radius: 5px;
			background-color: #fff; /* Set background color */
			width: calc(100% - 22px); /* Adjust width to fit within the container */
			box-sizing: border-box; /* Ensure padding and border are included in width */
		}
		
		.container input[type="date"]:focus {
			outline: none; /* Remove default focus outline */
			border-color: #007bff; /* Change border color on focus */
			box-shadow: 0 0 5px rgba(0, 123, 255, 0.5); /* Add a subtle box shadow */
		}
    </style>
</head>
<body>
    <div class="container">
        <h2>Software Usage Query</h2>
        <?php
        // Include necessary PHP files and initialize variables
        include("src/Model/User.php");
        include("view/Graph.php");
        $table = "licenseuserhistory_correct2";
        $user = new User;
        $graph = new Graph;
        $conn = $user->getConnection("localhost", "hpc", "root", "");

        // Fetch software list for dropdown
        $dataPoints = $graph->getSoftwares($conn, $user, $table);
        $softwareList = array_column($dataPoints, 'software');

        $error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $selectedSoftware = $_POST['software'];
            $fromDate = $_POST['from_date'];
            $toDate = $_POST['to_date'];

            if (empty($selectedSoftware) || empty($fromDate) || empty($toDate)) {
                $error = 'All fields are required.';
            } elseif (!in_array(strtolower($selectedSoftware), array_map('strtolower', $softwareList))) {
                $error = 'Invalid software name.';
            } elseif (strtotime($fromDate) > strtotime($toDate)) {
                $error = 'Start date must be before end date.';
            } else {
                // Redirect to software.php with selected parameters
                header('Location: software.php?software=' . urlencode($selectedSoftware) . '&from_date=' . urlencode($fromDate) . '&to_date=' . urlencode($toDate));
                exit();
            }
        }
        ?>
        <form method="post" action="">
            <?php if ($error): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php endif; ?>
            <div class="dropdown">
                <select id="software" name="software" required>
                    <option value="">Select Software</option>
                    <?php foreach ($softwareList as $software): ?>
                        <option value="<?php echo $software; ?>"><?php echo $software; ?></option>
                    <?php endforeach; ?>
                </select>
                <!-- Dropdown content removed -->
            </div>
            <input type="date" name="from_date" placeholder="Start Date" required>
            <input type="date" name="to_date" placeholder="End Date" required>
            <button type="submit">Submit</button>
        </form>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const softwareInput = document.getElementById('software');
            const dropdownContent = document.getElementById('dropdown-content');

            softwareInput.addEventListener('change', function() {
                // You can add further actions if needed
            });
        });
    </script>
</body>
</html>
