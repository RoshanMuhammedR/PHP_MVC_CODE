help me to write a report on a project I did. The project is basically presenting data graphically. The data contains info about the license usage of various software and its features by numerous users who ran the requested script in a hpc clucter (ivy). So divide the report into chapters.
the thing that I did Iam going to give you some points. Please don't mind the point numbering. you are allowed to have any numbering as you like. Be creative.

1. Prepare the data which was given to me.
	1.1 CSV file named "licensesuserhistory2" was given to me and i imported into as sql table using mysql cli. 

	1.2 table description
		lic_id - number given to each licenses.
		lic_server - The server in which the user requested sript
		software - The software which the user used
		feature - the name of the feature which user used
		username - username
		machine - the machine in which it was run in
		start_time - the time in which the license was issued
		time_of_mon - the time of monitoring for a particular table entry
		licenses - no. of licenses issued
		col1 - start_time
		col2 - end_time	
	1.3 Prepare the data. remove those rows who have null value in column time_of_mon.
	1.4 Create another column named start_time_standardized for storing the start time in a standard date time format. the date(mm and dd) is taken from start_time while year is taken from time_of_mon.
	1.5 Creating index for fatser searches. idx_software,idx_feature,idx_start_time_standardized,idx_username etc.
	1.6 Splitting the table into differnent table on the basis of software. i.e all the record of a particular software belongs to a table 	whith that software name.
	1.7 final list of all the table present


this is just the first part. i will give more inputs u just give the title and subtitle required

--------------------------------------------------------------------------------------------------------

this is for chapter 4 this chapter shows how i connected php to mysql data

<?php
class User {
    public function getConnection($host, $db_name, $username, $passwd) {
        $conn = mysqli_connect($host, $username, $passwd, $db_name);
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        return $conn;
    }

    public function fetchTableData($conn, $query) {
        if (!$conn) {
            die("Invalid connection");
        }

        $result = mysqli_query($conn, $query);
        if (!$result) {
            die("Query failed: " . mysqli_error($conn));
        }

        $data = mysqli_fetch_all($result, MYSQLI_ASSOC);

        mysqli_free_result($result);

        return $data;
    }
}
?>


it is done using this code. Please make a report chapter. Divide it into sub-chapter.
the function getConnection is used to estal. a connection to database and return $conn object (u should explain it) the func fetchTableData is used to fetch result from the database. you should creat a report in which there will be one main heading and sub-headings. add the code(extracted from above) in between to make the report understandable

------------------------------------------------------------------------------------------------------------

create chapter 5 for the report. This chapter is about designing the starting page index.php where the user will the asked a name of the software and starting time and ending time. The user will choose the software from a drop down and choose the dates from a calander. The graph which is shown in the further pages will be dated from the user provided from_date and to_date. the code is given below

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Software Usage Query</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: #f2f2f2;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: #fff;
            padding: 20px 40px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            text-align: center;
            width: 300px;
        }
        .container h2 {
            margin-bottom: 20px;
            color: #333;
        }
        .container form {
            display: flex;
            flex-direction: column;
        }
        .container select {
            margin-bottom: 15px;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .container button {
            padding: 10px;
            font-size: 16px;
            background: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .container button:hover {
            background: #0056b3;
        }
        .error {
            color: red;
            font-size: 14px;
            margin-bottom: 10px;
        }
        .dropdown {
            position: relative;
            display: inline-block;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 100%;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
            border-radius: 5px;
            max-height: 150px;
            overflow-y: auto;
        }
        .dropdown-content div {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            cursor: pointer;
        }
        .dropdown-content div:hover {
            background-color: #f1f1f1;
        }
		
		.container input[type="date"] {
			margin-bottom: 15px;
			padding: 10px;
			font-size: 16px;
			border: 1px solid #ddd;
			border-radius: 5px;
			background-color: #fff; /* Set background color */
			width: calc(100% - 22px); /* Adjust width to fit within the container */
			box-sizing: border-box; /* Ensure padding and border are included in width */
		}
		
		.container input[type="date"]:focus {
			outline: none; /* Remove default focus outline */
			border-color: #007bff; /* Change border color on focus */
			box-shadow: 0 0 5px rgba(0, 123, 255, 0.5); /* Add a subtle box shadow */
		}
    </style>
</head>
<body>
    <div class="container">
        <h2>Software Usage Query</h2>
        <?php
        // Include necessary PHP files and initialize variables
        include("src/Model/User.php");
        include("view/Graph.php");
        $table = "licenseuserhistory_correct2";
        $user = new User;
        $graph = new Graph;
        $conn = $user->getConnection("localhost", "hpc", "root", "");

        // Fetch software list for dropdown
        $dataPoints = $graph->getSoftwares($conn, $user, $table);
        $softwareList = array_column($dataPoints, 'software');

        $error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $selectedSoftware = $_POST['software'];
            $fromDate = $_POST['from_date'];
            $toDate = $_POST['to_date'];

            if (empty($selectedSoftware) || empty($fromDate) || empty($toDate)) {
                $error = 'All fields are required.';
            } elseif (!in_array(strtolower($selectedSoftware), array_map('strtolower', $softwareList))) {
                $error = 'Invalid software name.';
            } elseif (strtotime($fromDate) > strtotime($toDate)) {
                $error = 'Start date must be before end date.';
            } else {
                // Redirect to software.php with selected parameters
                header('Location: software.php?software=' . urlencode($selectedSoftware) . '&from_date=' . urlencode($fromDate) . '&to_date=' . urlencode($toDate));
                exit();
            }
        }
        ?>
        <form method="post" action="">
            <?php if ($error): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php endif; ?>
            <div class="dropdown">
                <select id="software" name="software" required>
                    <option value="">Select Software</option>
                    <?php foreach ($softwareList as $software): ?>
                        <option value="<?php echo $software; ?>"><?php echo $software; ?></option>
                    <?php endforeach; ?>
                </select>
                <!-- Dropdown content removed -->
            </div>
            <input type="date" name="from_date" placeholder="Start Date" required>
            <input type="date" name="to_date" placeholder="End Date" required>
            <button type="submit">Submit</button>
        </form>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const softwareInput = document.getElementById('software');
            const dropdownContent = document.getElementById('dropdown-content');

            softwareInput.addEventListener('change', function() {
                // You can add further actions if needed
            });
        });
    </script>
</body>
</html>


use the code and create a report. The report must contain a main title and sub- titles. The remote must be explained like this. First Main title the within sub-title some text and some code snippen you can short it and also explain the code

 --------------------------------------------------------------------------------------------------------------------------------------------

create a chapter 6 of the report which shows how the a particular section of the website which shows generalt statistics of the selected software from selected "from_time" to "to_time".

 <div class="primary-stats" >
	<div class="big-card">
		<h2>No. of Licenses Issued</h2>
		<h1><?php echo $licenseCount ?></h1>
	</div>
	<div class="grid-container">
		<div class="small-card">
			<h3>Users</h3>
			<h2><?php echo $userCount ?></h2>
		</div>
		<div class="small-card">
			<h3>Features</h3>
			<h2><?php echo $featureCount ?></h2>
		</div>
	</div>
</div>

	$featureCount = $graph->getFeatureCount($conn, $user, $table,$selectedSoftware);
	$userCount = $graph->getUserCount($conn, $user, $table,$selectedSoftware,$fromDate,$toDate);
	$licenseCount = $graph->getLicenseCount($conn, $user, $table,$selectedSoftware,$fromDate,$toDate);

function getLicenseCount($conn, $user, $table,$software,$from,$to){
		$sql = "select sum(licenses) as total_license from (select * from `$software` 
        where start_time_standardized between '$from' and '$to' group by username,machine,start_time_standardized) as limited;";
		$rows = $user->fetchTableData($conn, $sql);
		return $rows[0]['total_license'];
	}
	function getUserCount($conn, $user, $table,$software,$from,$to){
		$sql = "SELECT count(DISTINCT username) as total_user FROM `$software` FORCE INDEX (idx_username_start_time_standardized) WHERE 
        start_time_standardized BETWEEN '$from' AND '$to' ";
		$rows = $user->fetchTableData($conn, $sql);
		return $rows[0]['total_user'];
	}
	function getFeatureCount($conn, $user, $table,$software){
		$sql = "SELECT count(DISTINCT feature) as total_feature FROM `$software`";
		$rows = $user->fetchTableData($conn, $sql);
		return $rows[0]['total_feature'];
	}



use the code and create a report. The report must contain a main title and sub- titles. The remote must be explained like this. First Main title the within sub-title some text and some code snippen you can short it and also explain the code

--------------------------------------------------------------------------------------------------------------------------------------------

chapter 7 will show basics of chart.js and it's inmplementation using php.use the code and create a report. The report must contain a main title and sub- titles. The remote must be explained like this. First Main title the within sub-title some text and some code snippen you can short it and also explain the code

---------------------------------------------------------------------------------------------------------------------------------------------

chapter 8 will show the implementation of various graphs for presenting the data.
the graphs are
(1) Average lic issued per software vs time (line)
(2) License issued per feaature of a software (pie)
(3) Average lic issued per feature vs time (line)
(4) Users per feature vs time (line)
(5) Average lic issued per username vs time (line)
(6) selected software vs other software (bar)

for each graph write something on it and provide space for implementation. The implementation include the following

for graph (1)

    $dataPoints1 = $graph->getSoftwareFromTo($conn, $user, $table, $selectedSoftware, $fromDate, $toDate);

    <canvas id="chartContainer1" class="chartContainer"></canvas>

    function getSoftwareFromTo($conn,$user,$table,$software,$from,$to){
        $sql = "SELECT
					DATE(start_time_standardized) AS `date`,
					AVG(licenses) AS avg_licenses
				FROM 
					`$software`
				WHERE start_time_standardized BETWEEN '$from' and '$to'
				GROUP BY DATE(start_time_standardized)
				ORDER BY DATE(start_time_standardized);
        ";
		
		
        $rows = $user->fetchTableData($conn,$sql);
        return $rows;
    }

for graph (2) 

        $dataPoints5 = $graph->getFeatureStats($conn, $user, $table, $selectedSoftware, $fromDate, $toDate);

        <canvas id="chartContainer5" class="chartContainer"></canvas

        function getFeatureStats($conn,$user,$table,$software,$from,$to){
            $sql = "SELECT
                        feature,
                        SUM(licenses) AS no_licenses
                    FROM `$software`
                    WHERE start_time_standardized BETWEEN '$from' AND '$to'
                    GROUP BY feature
                    ORDER BY SUM(licenses) DESC;
                ";
            $rows = $user->fetchTableData($conn,$sql);
            return $rows;
        }

for graph (3)

    $dataPoints3 = $graph->getFeatureFromTo($conn, $user, $table, $selectedSoftware, $fromDate, $toDate);

    <canvas id="chartContainer3" class="chartContainer"></canvas>

    function getFeatureStats($conn,$user,$table,$software,$from,$to){
			$sql = "SELECT
						feature,
						SUM(licenses) AS no_licenses
					FROM `$software`
					WHERE start_time_standardized BETWEEN '$from' AND '$to'
					GROUP BY feature
					ORDER BY SUM(licenses) DESC;
				";
        $rows = $user->fetchTableData($conn,$sql);
        return $rows;
    }

for graph (4)

        $dataPoints4 = $graph->getUserPerFeature($conn, $user, $table, $selectedSoftware, $fromDate, $toDate);

        <canvas id="chartContainer4" class="chartContainer"></canvas>

        function getUserPerFeature($conn,$user,$table,$software,$from,$to){
        
        $rows = array();

        $sql1 = "SELECT DISTINCT(feature) as software_feature FROM `$software` 
                WHERE start_time_standardized  BETWEEN '$from' AND '$to'";
        $features = $user->fetchTableData($conn, $sql1);

        foreach ($features as $feature) {
            $featureName = $feature['software_feature'];
            $sql2 = "SELECT 
						DATE(start_time_standardized) AS date, 
						COUNT(DISTINCT username) AS user_count, 
						GROUP_CONCAT(DISTINCT username ORDER BY username SEPARATOR ', ') AS users
					FROM 
						`$software` FORCE INDEX (idx_feature_start_time_standardized_licenses)
					WHERE 
						feature = '$featureName' 
						AND 
						start_time_standardized BETWEEN '$from' AND '$to'
					GROUP BY 
						DATE(start_time_standardized)
					ORDER BY 
						DATE(start_time_standardized);

                    ";

            $featureData = $user->fetchTableData($conn, $sql2);
            $rows[$featureName] = $featureData;
        }
        return $rows;
    }

for graph (5)

    $dataPoints6 = $graph->getUserPerSoftware($conn, $user, $table, $selectedSoftware, $fromDate, $toDate);

    <canvas id="chartContainer6" class="chartContainer"></canvas>

    function getUserPerSoftware($conn,$user,$table,$software,$from,$to){
        $rows = array();
        $sql1 = "SELECT DISTINCT username from `$software` 
                where start_time_standardized BETWEEN '$from' AND '$to'";
        $usernames = $user->fetchTableData($conn, $sql1);

        foreach ($usernames as $username) {
            $user_name = $username['username'];
            $sql2 = "SELECT 
                        DATE(start_time_standardized) AS date,
                        AVG(licenses) AS avg_licenses
                    FROM 
						`$software`
                    WHERE 
                        username = '$user_name'
                        AND start_time_standardized BETWEEN '$from' AND '$to'
                    GROUP BY 
                        DATE(start_time_standardized)
                    ORDER BY
                        DATE(start_time_standardized)
                    ";

            $userData = $user->fetchTableData($conn, $sql2);
            $rows[$user_name] = $userData;
        }
        return $rows;
    }

for graph (6)

    $dataPoints2 = $graph->getSoftwareLicenseCount($conn, $user, $table, $selectedSoftware, $fromDate, $toDate)

    <canvas id="chartContainer2" class="chartContainer"></canvas>

    function getSoftwareLicenseCount($conn, $user, $table,$software,$from,$to){
		$software_tables = ['abaqus', 'ansys_17_1', 'ansys_19', 'cfd-ace/sysweld', 'comsol', 'recurdyn'];
		$excluded_software = $software;
        $rows = $user->fetchTableData($conn, "select software,sum(licenses) as no_licenses 
        from $table where start_time_standardized between '$from' and '$to' 
        group by software having software <>'$software';");
		
		$query_parts = [];

		foreach ($software_tables as $table) {
			if ($table != $excluded_software) {
				$query_parts[] = "SELECT '$table' AS software, SUM(licenses) AS no_licenses 
                FROM `$table` FORCE INDEX (idx_licenses)";
			}
		}
	
		$final_query = implode(' UNION ALL ', $query_parts) . ";";
		$rows = $user->fetchTableData($conn,$final_query);
		return $rows;
    }



use the code and create a report. The report must contain a main title and sub- titles. The remote must be explained like this. First Main title the within sub-title some text and some code snippen you can short it and also explain the code