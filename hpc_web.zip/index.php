<?php
include("src/App/Model/User.php");
include("View/Graph.php");

$table = "licenseuserhistory_correct2";
$user = new User;
$graph = new Graph;
$conn = $user->getConnection("localhost","hpc","root","");
$dataPoints1 = $graph->getServerCount($conn, $user, $table);
$dataPoints2 = $graph->getSoftwareCount($conn, $user, $table);
$dataPoints3 = $graph->getSoftwares($conn,$user,$table);
$dataPoints4 = $graph->getFeature($conn,$user,$table);
$dataPoints5 = $graph->getLicensesPerFeature($conn,$user,$table);

$selectedSoftware1 = '';
$selectedFeature = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $selectedSoftware1 = $_POST['software'];
    $selectedFeature = $_POST['feature'];
}
else{
    $selectedSoftware1 = $_GET['software'];
    $selectedFeature = $_GET['feature'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Graph Display</title>
    <style>
        .grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            grid-template-rows: 1fr 1fr;
            gap: 20px;
        }
        .chartContainer {
            height: 370px;
            width: 100%;
        }
    </style>
    <script src="https://cdn.canvasjs.com/canvasjs.min.js"></script>
    <script>
    window.onload = function () {
        var chart1 = new CanvasJS.Chart("chartContainer1", {
            animationEnabled: true,
            exportEnabled: true,
            theme: "light2",
            title: {
                text: "Server Count"
            },
            axisY: {
                includeZero: true
            },
            data: [{
                type: "column",
                indexLabelFontColor: "#5A5757",
                indexLabelPlacement: "inside",
                dataPoints: <?php echo json_encode($dataPoints1, JSON_NUMERIC_CHECK); ?>
            }]
        });
        chart1.render();

        var chart2 = new CanvasJS.Chart("chartContainer2", {
            animationEnabled: true,
            exportEnabled: true,
            title:{
                text: "Licenses Issued per Software"
            },
            subtitles: [{
                text: "Counts of Software Usage"
            }],
            data: [{
                type: "pie",
                explodeOnClick: false,
                showInLegend: "true",
                legendText: "{label}",
                indexLabelFontSize: 16,
                indexLabel: "{label} - #percent%",
                yValueFormatString: "#,##0",
                dataPoints: <?php echo json_encode($dataPoints2, JSON_NUMERIC_CHECK); ?>
            }]
        });
        chart2.render();

        var chart = new CanvasJS.Chart("chartContainer5", {
            animationEnabled: true,
            theme: "light2", // "light1", "light2", "dark1", "dark2"
            title: {
                text: "Licenses Per Feature"
            },
            axisX:{
                labelAngle: 0
            },
            axisY: {
                title: "No of Licenses"
            },
            data: [{
                type: "column",
                indexLabel: null,
                indexLabelFontColor: "#5A5757",
                dataPoints: <?php echo json_encode($dataPoints5, JSON_NUMERIC_CHECK); ?>
            }]
        });
        chart.render();
    }
    </script>
</head>
<body>
    <div class="grid">
        <div id="chartContainer1" class="chartContainer"></div>
        <div id="chartContainer2" class="chartContainer"></div>
        <div class="software-count">
            <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="get">
                <select name="software">
                    <?php
                        foreach($dataPoints3 as $row){
                            $selected = ($row['software'] == $selectedSoftware1) ? 'selected' : '';
                            echo "<option value='" . htmlspecialchars($row['software']) . "' $selected>" . htmlspecialchars($row['software']) . "</option>";
                        }
                    ?>
                </select>
                <select name="feature">
                    <?php
                        foreach($dataPoints4 as $row){
                            $selected = ($row['feature'] == $selectedFeature) ? 'selected' : '';
                            echo "<option value='" . htmlspecialchars($row['feature']) . "' $selected>" . htmlspecialchars($row['feature']) . "</option>";
                        }
                    ?>
                </select>
                <input type="submit">
            </form>
            <?php
                if ($_SERVER["REQUEST_METHOD"] == "GET") {
                    echo "You have selected: <br>";
                    echo "Software: " . htmlspecialchars($selectedSoftware1) . "<br>";
                    echo "Feature: " . htmlspecialchars($selectedFeature) . "<br>";
                }
            ?>
        </div>
        <div class="chartContainer" id="chartContainer5"></div>
    </div>
</body>
</html>
