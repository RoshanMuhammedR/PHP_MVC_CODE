<?php
    include("src/App/Model/User.php");
    $user = new User;
    $conn = $user->getConnection("localhost","hpc","root","");

    if(isset($_GET['software'])){
        $software = $_GET['software'];
        $feature = $graph->getFeatureBySoftware($conn,$user,$table,$software);
        echo json_encode($features);
    }
?>