<?php
class User {
    public function getConnection($host, $db_name, $username, $passwd) {
        $conn = mysqli_connect($host, $username, $passwd, $db_name);
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        echo "Connected to Database Successfully<br>";
        return $conn;
    }

    public function fetchTableData($conn, $query) {
        if (!$conn) {
            die("Invalid connection");
        }

        $result = mysqli_query($conn, $query);
        if (!$result) {
            die("Query failed: " . mysqli_error($conn));
        }

        $data = mysqli_fetch_all($result, MYSQLI_ASSOC);

        mysqli_free_result($result);

        return $data;
    }
}
?>
