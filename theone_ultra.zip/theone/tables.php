<?php
    session_start();	
	
?>

<!DOCTYPE html>
<html>
<head>
    <title>Table</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.16.2/xlsx.full.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        .table-container {
            width: 80%;
            max-height: 400px;
            margin: 20px auto;
            overflow-y: auto;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 8px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #ddd;
        }
        .button-container {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin: 20px auto;
        }
        button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #45a049;
        }
        .download-button{
            position: relative; 
            left: 10%;
        }
		.title h3{
			position: relative; 
            left: 10%;
		}
    </style>
</head>
<body>

<h2>Tabular Data Display</h2>

<div class="button-container">
    <button onclick="toggleDisplay('singular');">
		Show Singular Table
	</button>
	<button onclick="toggleDisplay('multiple');">
		Show Multiple Tables
	</button>
</div>

<div class="title" id="title-single" style="display: block;">
	<h3>Data Displayed in Single Table
</div>

<div id="singularTable" class="table-container" style="display: block;">
	<table>
		<tr>
			<th>Feature</th>
			<th>Date</th>
			<th>Licenses</th>
		</tr>
		<?php
		if (isset($_SESSION['dataPoints']) && !empty($_SESSION['dataPoints'])) {
			foreach ($_SESSION['dataPoints'] as $software => $rows) {
				foreach ($rows as $row) {
					echo "<tr>";
					echo "<td>$software</td>";
					echo "<td>{$row['date']}</td>";
					echo "<td>{$row['avg_licenses']}</td>";
					echo "</tr>";
				}
			}
		}
		?>
	</table>
</div>

<div id="download-button-single" style="display: block;">
    <button class="download-button" onclick="exportTableToCSV('data_singular.csv', 'singularTable')">Download Data</button>
</div>

<div class="title" id="title-multiple" style="display: none;">
	<h3>Data Displayed in Split Tables
</div>

<div id="multipleTables" style="display: none;">
    <div>
        <?php
        if (isset($_SESSION['dataPoints']) && !empty($_SESSION['dataPoints'])) {
            foreach ($_SESSION['dataPoints'] as $software => $rows) {
                echo "<div class='table-container' id='{$software}_table' >";
                echo "<h2>$software</h2>";
                echo "<table>";
                echo "<tr><th>Date</th><th>Licenses</th></tr>";
                foreach ($rows as $row) {
                    echo "<tr>";
                    echo "<td>{$row['date']}</td>";
                    echo "<td>{$row['avg_licenses']}</td>";
                    echo "</tr>";
                }
                echo "</table>";
                echo "</div>";  
                echo "<button class='download-button' onclick=\"exportTableToCSV('data_{$software}.csv', '{$software}_table')\">Download Data</button>";
            }
        }
        ?>
    </div>
</div>


<div class="button-container">
    <button onclick="goBack()">Go Back</button>
</div>

<script>
	function exportTableToCSV(filename, tableId) {
		var table = document.getElementById(tableId).getElementsByTagName('table')[0];
		var workbook = XLSX.utils.table_to_book(table, {sheet: "Sheet1"});
		XLSX.writeFile(workbook, filename);
	}

	function toggleDisplay(type) {
		if (type === 'singular') {
			document.getElementById('title-multiple').style.display = 'none';
			document.getElementById('title-single').style.display = 'block';
			document.getElementById('singularTable').style.display = 'block';
			document.getElementById('multipleTables').style.display = 'none';
			document.getElementById('download-button-single').style.display = 'block';
		} else if (type === 'multiple') {
			document.getElementById('title-multiple').style.display = 'block';
			document.getElementById('title-single').style.display = 'none';
			document.getElementById('singularTable').style.display = 'none';
			document.getElementById('multipleTables').style.display = 'block';
			document.getElementById('download-button-single').style.display = 'none';
		}
	}

	function goBack() {
		window.history.back();
	}
</script>

</body>
</html>
