<?php
class Graph {
	
	
	function getLicenseCount($conn, $user, $table){
		$sql = "SELECT SUM(licenses) as total_license from $table";
		$rows = $user->fetchTableData($conn, $sql);
		return $rows[0]['total_license'];
	}
	function getServerCount($conn, $user, $table){
		$sql = "SELECT count(DISTINCT lic_server) as total_server from $table";
		$rows = $user->fetchTableData($conn, $sql);
		return $rows[0]['total_server'];
	}
	function getUserCount($conn, $user, $table){
		$sql = "SELECT count(DISTINCT username) as total_user from $table";
		$rows = $user->fetchTableData($conn, $sql);
		return $rows[0]['total_user'];
	}
	function getSoftwareCount($conn, $user, $table){
		$sql = "SELECT count(DISTINCT software) as total_software from $table";
		$rows = $user->fetchTableData($conn, $sql);
		return $rows[0]['total_software'];
	}
	function getFeatureCount($conn, $user, $table){
		$sql = "SELECT count(DISTINCT feature) as total_feature from $table";
		$rows = $user->fetchTableData($conn, $sql);
		return $rows[0]['total_feature'];
	}
	
	
    function getServerLicenseCount($conn, $user, $table) {
        $rows = $user->fetchTableData($conn, "SELECT lic_server, SUM(licenses) as count FROM $table GROUP BY lic_server");
        $server_names = [];
        $server_count = [];
        
        foreach ($rows as $row) {
            $server_names[] = $row['lic_server'];
            $server_count[] = $row['count'];
        }

        $dataPoints1 = [];
        $x = 10;

        for ($i = 0; $i < count($server_count); $i++) {
            $dataPoints1[] = ['x' => $x, 'y' => $server_count[$i], 'label' => $server_names[$i]];
            $x += 10;
        }

        return $dataPoints1;
    }

    function getSoftwareLicenseCount($conn, $user, $table){
        $rows = $user->fetchTableData($conn, "SELECT software, SUM(licenses) as count FROM $table GROUP BY software;");
        $dataPoints2 = [];

        foreach ($rows as $row) {
            $dataPoints2[] = [
                "label" => $row["software"],
                "y" => $row["count"]
            ];
        }

        return $dataPoints2;
    }

    function getSoftwares($conn,$user,$table){
        $rows = $user->fetchTableData($conn,"SELECT DISTINCT(software) FROM $table;");
        return $rows;
    }

    function getFeature($conn,$user,$table){
        $rows = $user->fetchTableData($conn,"SELECT DISTINCT(feature) FROM $table;");
        return $rows;
    }

    function getLicensesPerFeature($conn,$user,$table,$from,$to){
        $sql = "SELECT feature, SUM(licenses) as No_Of_licenses
                FROM $table USE INDEX (idx_feature_start_time_standardized_licenses)
                GROUP BY feature;
                ";
        $rows = $user->fetchTableData($conn, $sql);
        return $rows;
    }

    function getUsernameFromTo($conn,$user,$table,$username,$from,$to){
		$sql = "
            SELECT 
				DATE(start_time_standardized) AS date, 
				AVG(licenses) AS avg_licenses
			FROM 
				$table
			WHERE 
				username = '$username'
				AND start_time_standardized BETWEEN '$from' AND '$to'
			GROUP BY 
				DATE(start_time_standardized)
			ORDER BY 
				DATE(start_time_standardized);
        ";
		$rows = $user->fetchTableData($conn,$sql);
        return $rows;   
    }
    function getSoftwareFromTo($conn,$user,$table,$software,$from,$to){
        $sql = "
            SELECT date(start_time_standardized) as date, avg(licenses) as avg_licenses
            FROM $table
            WHERE software = '$software'
            AND start_time_standardized BETWEEN '$from' AND '$to'
            GROUP BY date(start_time_standardized)
            ORDER BY date(start_time_standardized)
        ";
        $rows = $user->fetchTableData($conn,$sql);
        return $rows;
    }

    function getFeatureFromTo($conn,$user,$table,$feature,$from,$to){
        $sql = "SELECT 
                    date(start_time_standardized) as date, avg(licenses) as avg_licenses
                FROM 
                    $table
                WHERE 
                    feature = '$feature'
                AND 
                    start_time_standardized BETWEEN '$from' AND '$to'
                GROUP BY 
                    date(start_time_standardized)
                ORDER BY 
                    date(start_time_standardized)
        ";
        $rows = $user->fetchTableData($conn,$sql);
        return $rows;
    }

    function getFeaturePerSoftware($conn,$user,$table,$software,$from,$to){
        if($software=="None Selected"){
            return;
        }
        $sql = "SELECT feature,SUM(licenses) FROM $table WHERE software = '$software' AND start_time_standardized BETWEEN '$from' AND '$to'  GROUP BY feature";
        $rows = $user->fetchTableData($conn,$sql);
        return $rows;
    }




    function getUserPerSoftware($conn,$user,$table,$software,$from,$to){
        $sql = "SELECT 
                    DATE(start_time_standardized) AS date,
                    COUNT(DISTINCT username) AS user_count,
                    GROUP_CONCAT(DISTINCT username ORDER BY username SEPARATOR ', ') AS users
                FROM 
                    $table 
                WHERE 
                    software = '$software' 
                    AND start_time_standardized BETWEEN '$from' AND '$to'
                GROUP BY 
                    DATE(start_time_standardized)
                ORDER BY 
                    DATE(start_time_standardized);
                ";
        $rows = $user->fetchTableData($conn,$sql);
        return $rows;
    }
	
	function getUserPerFeature($conn,$user,$table,$feature,$from,$to){
        $sql = "SELECT 
                    DATE(start_time_standardized) AS date,
                    COUNT(DISTINCT username) AS user_count,
                    GROUP_CONCAT(DISTINCT username ORDER BY username SEPARATOR ', ') AS users
                FROM 
                    $table 
                WHERE 
                    feature = '$feature' 
                    AND start_time_standardized BETWEEN '$from' AND '$to'
                GROUP BY 
                    DATE(start_time_standardized)
                ORDER BY 
                    DATE(start_time_standardized);
                ";
        $rows = $user->fetchTableData($conn,$sql);
        return $rows;
    }

    function getUsers($conn,$user,$table){
        $sql = "SELECT DISTINCT username AS user FROM $table";
        $rows = $user->fetchTableData($conn,$sql);
        return $rows;
    }
	
	function getSoftwarePerUsername($conn,$user,$table,$username,$from,$to){
		$sql  =	"SELECT
					software,
					SUM(licenses) AS total_licenses
				FROM
					$table
				WHERE
					username = '$username'
					AND start_time_standardized BETWEEN '$from' AND '$to'
				GROUP BY
					software;
				";
		$rows = $user->fetchTableData($conn,$sql);
        return $rows;
	}
	
	function getFeaturePerUsername($conn,$user,$table,$username,$from,$to){
		$sql  =	"SELECT
					feature,
					SUM(licenses) AS total_licenses
				FROM
					$table
				WHERE
					username = '$username'
					AND start_time_standardized BETWEEN '$from' AND '$to'
				GROUP BY
					feature;
				";
		$rows = $user->fetchTableData($conn,$sql);
        return $rows;
		
	}
	
}
?>



