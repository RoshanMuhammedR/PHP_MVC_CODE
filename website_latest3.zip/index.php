<?php
include("src/App/Model/User.php");
include("View/Graph.php");

$table = "licenseuserhistory_correct2";
$user = new User;
$graph = new Graph;

$conn = $user->getConnection("localhost", "hpc", "root", "");

$currentDate = date('Y-m-d');
$oldDate = date('Y-m-d', strtotime('-12 months'));




function printDuration($start_time, $message) {
    $end_time = microtime(true);
    $duration = $end_time - $start_time;
    echo "$message: " . number_format($duration, 4) . " seconds<br>";
}

$start_time = microtime(true);

/* count */

$licenses = $graph->getLicenseCount($conn, $user, $table);
printDuration($start_time, 'Time after getting license count');

$server = $graph->getServerCount($conn, $user, $table);
printDuration($start_time, 'Time after getting server count');

$users = $graph->getUserCount($conn, $user, $table);
printDuration($start_time, 'Time after getting user count');

$software = $graph->getSoftwareCount($conn, $user, $table);
printDuration($start_time, 'Time after getting software count');

$feature = $graph->getFeatureCount($conn, $user, $table);
printDuration($start_time, 'Time after getting feature count');

/* count */

/*selection software*/

$selectedSoftware = $_POST['software'] ?? $_GET['software'] ?? 'COMSOL';
$selectedFeature = $_POST['feature'] ?? $_GET['feature'] ?? 'abaqus';
$selectedUser = $_POST['user'] ?? $_GET['user'] ?? 'askmanson';

/*selection software*/

/*dates*/
$fromDateSoftware = $_POST['from_date_software'] ?? $_GET['from_date_software'] ?? $oldDate;
$toDateSoftware = $_POST['to_date_software'] ?? $_GET['to_date_software'] ?? $currentDate;

$fromDateUser = $_POST['from_date_user'] ?? $_GET['from_date_user'] ?? $oldDate;
$toDateUser = $_POST['to_date_user'] ?? $_GET['to_date_user'] ?? $currentDate;

$fromDateFeature = $_POST['from_date_feature'] ?? $_GET['from_date_feature'] ?? $oldDate;
$toDateFeature = $_POST['to_date_feature'] ?? $_GET['to_date_feature'] ?? $currentDate;

/*dates*/



$dataPoints1 = $graph->getServerLicenseCount($conn, $user, $table);
printDuration($start_time, 'Time after getting server license count');

$dataPoints2 = $graph->getSoftwareLicenseCount($conn, $user, $table);
printDuration($start_time, 'Time after getting software license count');

$dataPoints3 = $graph->getSoftwares($conn, $user, $table);
printDuration($start_time, 'Time after getting software list');

$dataPoints4 = $graph->getFeature($conn, $user, $table);
printDuration($start_time, 'Time after getting feature list');

/* software function */

$dataPoints5 = $graph->getSoftwareFromTo($conn, $user, $table, $selectedSoftware, $fromDateSoftware, $toDateSoftware);
printDuration($start_time, 'Time after getting software from-to date');

$dataPoints6 = $graph->getFeaturePerSoftware($conn, $user, $table, $selectedSoftware, $fromDateSoftware, $toDateSoftware);
printDuration($start_time, 'Time after getting feature per software');


$dataPoints7 = $graph->getUserPerSoftware($conn, $user, $table, $selectedSoftware, $fromDateSoftware, $toDateSoftware);
printDuration($start_time, 'Time after getting user per software');

$dataPoints8 = $graph->getLicensesPerFeature($conn, $user, $table, $fromDateSoftware, $toDateSoftware);
printDuration($start_time, 'Time after getting licenses per feature');

/* software function */

/* feature function */

$dataPoints9 = $graph->getFeatureFromTo($conn, $user, $table, $selectedFeature, $fromDateFeature, $toDateFeature);
printDuration($start_time, 'Time after getting feature from-to date');

$dataPoints10 = $graph->getUserPerFeature($conn, $user, $table, $selectedFeature, $fromDateFeature, $toDateFeature);
printDuration($start_time, 'Time after getting user per feature');

/* feature function */


/* user function */

$dataPoints11 = $graph->getUsers($conn, $user, $table);
printDuration($start_time, 'Time after getting user list');

$dataPoints12 = $graph->getUsernameFromTo($conn,$user,$table,$selectedUser,$fromDateUser,$toDateUser);
printDuration($start_time, 'Time after getting user avg. license usage');

$dataPoints13 = $graph->getSoftwarePerUsername($conn,$user,$table,$selectedUser,$fromDateUser,$toDateUser);
printDuration($start_time, 'Time after getting user software usage');

$dataPoints14 = $graph->getFeaturePerUsername($conn,$user,$table,$selectedUser,$fromDateUser,$toDateUser);
printDuration($start_time, 'Time after getting user feature usage');


/* user function */

$SoftwareColor = [
    'Abaqus'=>'rgba(255, 99, 132, 0.5)',
    'ANSYS_17_1'=>'rgba(54, 162, 235, 0.5)',
    'ANSYS_19'=>'rgba(255, 206, 86, 0.5)',
    'CFD-ACE/SYSWELD'=>'rgba(75, 192, 192, 0.5)',
    'COMSOL'=>'rgba(153, 102, 255, 0.5)',
    'RECURDYN'=>'rgba(255, 159, 64, 0.5)'
];
	
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Graph Display</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
	<link rel="stylesheet" href = "view/asset/style.css">
</head>
<body>
	<div class="flex-container">
		<div class="flex">
			<div class="primary-stats" >
				<div class="big-card">
					<h2>No. of Licenses Issued</h2>
					<h1><?php echo $licenses ?></h1>
				</div>
				<div class="grid-container">
					<div class="small-card">
						<h3>Servers</h3>
						<h2><?php echo $server ?></h2>
					</div>
					<div class="small-card">
						<h3>Users</h3>
						<h2><?php echo $users ?></h2>
					</div>
					<div class="small-card">
						<h3>Softwares</h3>
						<h2><?php echo $software ?></h2>
					</div>
					<div class="small-card">
						<h3>Features</h3>
						<h2><?php echo $feature ?></h2>
					</div>
				</div>
			</div>
		
		
		
			<div class="server-usage">
				<canvas id="chartContainer1" class="chartContainer"></canvas>
			</div>
			<div class="software-usage">
				<canvas id="chartContainer2" class="chartContainer"></canvas>
			</div>

			<div class="feature-usage">
				<canvas id="chartContainer6" class="chartContainer"></canvas>
			</div>

			<hr>

			<div class="software-count">
				<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="get">
					<select name="software">
						<?php
							foreach($dataPoints3 as $row){
								$selected = ($row['software'] == $selectedSoftware) ? 'selected' : '';
								echo "<option value='" . htmlspecialchars($row['software']) . "' $selected>" . htmlspecialchars($row['software']) . "</option>";
							}
						?>
					</select>
					<div class="date-from-to">
						<div style = "display:flex;">
							<div>
								<h4>From:
								<input type="date"
									   id="Test_DatetimeLocal"
									   name = "from_date_software"
									   min="2015-01-01T00:00"
									   max="2025-12-31T23:59"
									   step="1">
								</h4>
							</div>
						
							<div>
								<h4>To:
								<input type="date"
									   id="Test_DatetimeLocal"
									   name = "to_date_software"
									   min="2015-01-01T00:00"
									   max="2025-12-31T23:59"
									   step="1">
								</h4>
							</div>
							</div>
					</div>
					
					<input type="submit">
				</form>
				<?php
					echo "You have selected: <br>";
					echo "Software: " . htmlspecialchars($selectedSoftware) . "<br>";
					echo "From Date: " .$fromDateSoftware . "<br>";
					echo "To Date: " . $toDateSoftware . "<br>";

				?>
			</div>
			<div class="selected-Software">
				<canvas id="chartContainer3" class="chartContainer"></canvas>
			</div>
			<div class="select-Software-feature-ratio">
				<canvas id="chartContainer4" class="chartContainer"></canvas>
			</div>
			<div class="select-software-user-info">
				<canvas id="chartContainer5" class="chartContainer"></canvas>
			</div>

			<hr>
			
			<div style="display:flex; flex-direction:column; justify-content:center">
				<div style="display: flex; justify-content: center;"> 
					<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="get">
						<div class="date-align" style="display: flex;flex-direction:column;align-items:center">
							<div>
								<select name="feature">
									<?php
										foreach($dataPoints4 as $row){
											$selected = ($row['feature'] == $selectedFeature) ? 'selected' : '';
											echo "<option value='" . htmlspecialchars($row['feature']) . "' $selected>" . htmlspecialchars($row['feature']) . "</option>";
										}
									?>
								</select>
							</div>
							<div class="date-from-to">
								<div style = "display:flex;">
									<div>
										<h4>From:
										<input type="date"
											   id="Test_DatetimeLocal"
											   name = "from_date_feature"
											   min="2015-01-01T00:00"
											   max="2025-12-31T23:59"
											   step="1">
										</h4>
									</div>
									<div>
										<h4>To:
										<input type="date"
											   id="Test_DatetimeLocal"
											   name = "to_date_feature"
											   min="2015-01-01T00:00"
											   max="2025-12-31T23:59"
											   step="1">
										</h4>
									</div>
									</div>
							</div>
							<div>
								<input type="submit">
							</div>
						</div>
					</form>
				</div>
				<div style="text-align:center;">
					<?php
						echo "You have selected: <br>";
						echo "Feature: " . htmlspecialchars($selectedFeature) . "<br>";
						echo "From Date: " .$fromDateFeature . "<br>";
						echo "To Date: " . $toDateFeature . "<br>";
					?>
				</div>
			</div>

			<div class="select-feature">
				<canvas id="chartContainer7" class="chartContainer"></canvas>
			</div>
			
			<div class="select-feature">
				<canvas id="chartContainer8" class="chartContainer"></canvas>
			</div>

			<hr>
			<div style="display:flex; flex-direction:column; justify-content:center">
				<div style="display: flex; justify-content: center;"> 
					<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="get">
						<div class="date-align" style="display: flex;flex-direction:column;align-items:center">
							<div>
								<select name="user">
									<?php
										foreach($dataPoints11 as $row){
											$selected = ($row['user'] == $selectedUser) ? 'selected' : '';
											echo "<option value='" . htmlspecialchars($row['user']) . "' $selected>" . htmlspecialchars($row['user']) . "</option>";
										}
									?>
								</select>
							</div>
							<div class="date-from-to">
								<div style = "display:flex;">
									<div>
										<h4>From:
										<input type="date"
											   id="Test_DatetimeLocal"
											   name = "from_date_user"
											   min="2015-01-01T00:00"
											   max="2025-12-31T23:59"
											   step="1">
										</h4>
									</div>
									<div>
										<h4>To:
										<input type="date"
											   id="Test_DatetimeLocal"
											   name = "to_date_user"
											   min="2015-01-01T00:00"
											   max="2025-12-31T23:59"
											   step="1">
										</h4>
									</div>
									</div>
							</div>
							<div>
								<input type="submit">
							</div>
						</div>
					</form>
				</div>
				<div style="text-align:center;">
					<?php
						echo "You have selected: <br>";
						echo "User: " . htmlspecialchars($selectedUser) . "<br>";
						echo "From Date: " .$fromDateUser . "<br>";
						echo "To Date: " . $toDateUser . "<br>";
					?>
				</div>
			</div>
			
			<div class="select-user">
				<canvas id="chartContainer9" class="chartContainer"></canvas>
			</div>
			
			<div class="select-user-software">
				<canvas id="chartContainer10" class="chartContainer"></canvas>
			</div>
			
			<div class="select-user-feature">
				<canvas id="chartContainer11" class="chartContainer"></canvas>
			</div>
		</div>
	</div>
    
    <script>
    window.onload = function () {
        var SoftwareColor = <?php echo json_encode($SoftwareColor); ?>;
        var ctx1 = document.getElementById('chartContainer1').getContext('2d');
        var chart1 = new Chart(ctx1, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_column($dataPoints1, 'label')); ?>,
                datasets: [{
                    label: 'Licenses Issued per Server',
                    data: <?php echo json_encode(array_column($dataPoints1, 'y')); ?>,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.5)',
                        'rgba(54, 162, 235, 0.5)',
                        'rgba(255, 206, 86, 0.5)',
                        'rgba(75, 192, 192, 0.5)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 0.5)',
                        'rgba(54, 162, 235, 0.5)',
                        'rgba(255, 206, 86, 0.5)',
                        'rgba(75, 192, 192, 0.5)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
						title: {
							display: true,
							text: 'Number of Licenses',
							font: {
								size: 16,
								family: 'Arial', 
								style: 'normal',
								lineHeight: 1.2
							},
							color: '#000',
							padding: {top: 10, left: 0, right: 0, bottom: 10}
						},
                    },
					x: {
						title: {
							display: true,
							text: "Server Name",
							font: {
								size: 16,
								family: 'Arial',
								style: 'normal',
								lineheight: 1.2
							},
							color: '#000',
							padding: {top: 10, left: 0, right: 0, bottom: 10}
						}
					}
                },
                plugins: {
                    title: {
                    display: true,
                    text: 'Server Usage',
                    padding: {
                        top: 10,
                        bottom: 10
                    },
                    font: {
                    size: 50 
                    }
                }
            }
	    }
        });

        var ctx2 = document.getElementById('chartContainer2').getContext('2d');
        var chart2 = new Chart(ctx2, {
            type: 'pie',
            data: {
                labels: <?php echo json_encode(array_column($dataPoints2, 'label')); ?>,
                datasets: [{
                    label: 'Licenses Issued per Software',
                    data: <?php echo json_encode(array_column($dataPoints2, 'y')); ?>,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.5)',
                        'rgba(54, 162, 235, 0.5)',
                        'rgba(255, 206, 86, 0.5)',
                        'rgba(75, 192, 192, 0.5)',
                        'rgba(153, 102, 255, 0.5)',
                        'rgba(255, 159, 64, 0.5)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 0.5)',
                        'rgba(54, 162, 235, 0.5)',
                        'rgba(255, 206, 86, 0.5)',
                        'rgba(75, 192, 192, 0.5)',
                        'rgba(153, 102, 255, 0.5)',
                        'rgba(255, 159, 64, 0.5)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Software Usage',
                        padding: {
                            top: 10,
                            bottom: 10
                        },
                        font: {
                            size: 50 
                        }
                    }
                }
            }
        });

        var ctx3 = document.getElementById('chartContainer3').getContext('2d');
        var chart3 = new Chart(ctx3, {
            type: 'line',
            data: {
                labels: <?php echo json_encode(array_column($dataPoints5, 'date')); ?>,
                datasets: [{
                    label: '<?php echo htmlspecialchars($selectedSoftware); ?>'+"'s "+"Average License Usage",
                    data: <?php echo json_encode(array_column($dataPoints5, 'avg_licenses')); ?>,
                    backgroundColor: SoftwareColor["<?php echo htmlspecialchars($selectedSoftware); ?>"],
                    borderColor: SoftwareColor["<?php echo htmlspecialchars($selectedSoftware); ?>"],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: false,
						title: {
							display: true,
							text: 'Average Licenses Issued',
							font: {
								size: 16, 
								family: 'Arial', 
								style: 'normal',
								lineHeight: 1.2
							},
							color: '#000', 
							padding: {top: 10, left: 0, right: 0, bottom: 10}
						}
                    },
					x: {
						title: {
							display: true,
							text: 'Date',
							font: {
								size: 16, 
								family: 'Arial', 
								style: 'normal',
								lineHeight: 1.2
							},
							color: '#000', 
							padding: {top: 10, left: 0, right: 0, bottom: 10}
						}
					}
                },
                plugins: {
                    title: {
                        display: true,
                        text: 'Average Number of ' + '<?php echo htmlspecialchars($selectedSoftware); ?>'+ ' Licenses Issued',
                        padding: {
                            top: 10,
                            bottom: 10
                        },
                        font: {
                            size: 50
                        }
                    },
                    tooltip: {
						mode: 'index',
						intersect: false
                    },
					interaction: {
						mode: 'index', 
						intersect: false 
					},
                }
            }
        });

        var ctx4 = document.getElementById('chartContainer4').getContext('2d');
        var chart4 = new Chart(ctx4, {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode(array_column($dataPoints6, 'feature')); ?>,
                datasets: [{
                    label: 'Licenses Issued per Software',
                    data: <?php echo json_encode(array_column($dataPoints6, 'SUM(licenses)')); ?>,
                    backgroundColor: <?php
                        $colors = [];
                        for ($i = 0; $i < count($dataPoints6); $i++) {
                            $randomColor = sprintf('rgba(%d, %d, %d, 0.7)', mt_rand(50, 255), mt_rand(50, 255), mt_rand(50, 255));
                            $colors[] = $randomColor;
                        }
                        echo json_encode($colors);
                        ?>,
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Feature Usage Of '+'<?php echo htmlspecialchars($selectedSoftware); ?>',
                        padding: {
                            top: 10,
                            bottom: 10
                        },
                        font: {
                            size: 50 
                        }
                    }
                }
            }
        });
        
        var ctx5 = document.getElementById('chartContainer5').getContext('2d');
        var chart5 = new Chart(ctx5, {
            type: 'line',
            data: {
                labels: <?php echo json_encode(array_column($dataPoints7, 'date')); ?>,
                datasets: [{
                    label: '<?php echo htmlspecialchars($selectedSoftware); ?>'+"'s "+"User Count",
                    data: <?php echo json_encode(array_column($dataPoints7, 'user_count')); ?>,
                    borderWidth: 1,
                    pointBackgroundColor: 'rgba(75, 192, 192, 0.6)',
                    pointBorderColor: 'rgba(75, 192, 192, 1)',
                    pointBorderWidth: 1,
                    pointRadius: 2,
                    fill: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
						afterDataLimits: function(axis) {
							var max = axis.max;
							axis.max = max + Math.ceil(max * 0.25); 
						},
						ticks: {
						  stepSize: 1
						},
						title: {
							display: true,
							text: 'No. Of Users',
							font: {
								size: 16, 
								family: 'Arial', 
								style: 'normal',
								lineHeight: 1.2
							},
							color: '#000', 
							padding: {top: 10, left: 0, right: 0, bottom: 10}
						}
                    },
					x: {
						title: {
							display: true,
							text: 'Date',
							font: {
								size: 16, 
								family: 'Arial', 
								style: 'normal',
								lineHeight: 1.2
							},
							color: '#000', 
							padding: {top: 10, left: 0, right: 0, bottom: 10}
						}
					}
                },
                plugins: {
                    tooltip: {
						mode: 'index',
						intersect: false,
                        callbacks: {
                            label: function(context) {
                                var users = <?php echo json_encode(array_column($dataPoints7, 'users')); ?>;
                                return context.raw + ': ' + users[context.dataIndex];
                            }
                        }
                    },
					interaction: {
						mode: 'index', 
						intersect: false 
					},
                    title: {
                        display: true,
                        text: 'Number of ' + '<?php echo htmlspecialchars($selectedSoftware); ?>'+ ' Users',
                        padding: {
                            top: 10,
                            bottom: 10
                        },
                        font: {
                            size: 50
                        }
                    }
                }
            }
        });


        
        var ctx6 = document.getElementById('chartContainer6').getContext('2d');
        var chart6 = new Chart(ctx6, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_column($dataPoints8, 'feature')); ?>,
                datasets: [{
                    label: " License Usage Of Features (Small Values)",
                    data: <?php echo json_encode(array_map(function($value) { return $value <= 100 ? $value : null; }, array_column($dataPoints8, 'No_Of_licenses'))); ?>,
                    borderWidth: 1,
                    yAxisID: 'y',
                    backgroundColor: 'rgba(75, 192, 192, 0.6)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    labels: <?php echo json_encode(array_column(array_filter($dataPoints8, function($value) { return $value['No_Of_licenses'] <= 100; }), 'feature')); ?> // Labels for small values
                }, {
                    label: "Average License Usage Of Features (Large Values)",
                    data: <?php echo json_encode(array_map(function($value) { return $value > 100 ? $value : null; }, array_column($dataPoints8, 'No_Of_licenses'))); ?>,
                    borderWidth: 1,
                    yAxisID: 'y1',
                    backgroundColor: 'rgba(255, 99, 132, 0.6)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    labels: <?php echo json_encode(array_column(array_filter($dataPoints8, function($value) { return $value['No_Of_licenses'] > 100; }), 'feature')); ?> // Labels for large values
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: "Features",
                            font: {
                                size: 16, 
                                family: 'Arial', 
                                style: 'normal',
                                lineHeight: 1.2
                            },
                            color: '#000', 
                            padding: {top: 5, left: 0, right: 0, bottom: 10}
                        }
                    },
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return value <= 100 ? value : '';
                            }
                        },
                        title: {
                            display: true,
                            text: 'Small Values',
                            font: {
                                size: 16, 
                                family: 'Arial', 
                                style: 'normal',
                                lineHeight: 1.2
                            },
                            color: '#000', 
                            padding: {top: 10, left: 0, right: 0, bottom: 10}
                        }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return value > 100 ? value : '';
                            }
                        },
                        grid: {
                            drawOnChartArea: false 
                        },
                        title: {
                            display: true,
                            text: 'Large Values',
                            font: {
                                size: 16, 
                                family: 'Arial', 
                                style: 'normal',
                                lineHeight: 1.2
                            },
                            color: '#000', 
                            padding: {top: 10, left: 0, right: 0, bottom: 10}
                        }
                    }
                },
                plugins: {
                    title: {
                        display: true,
                        text: 'License Usage Of Features',
                        padding: {
                            top: 10,
                            bottom: 10
                        },
                        font: {
                            size: 20
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.dataset.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                label += context.raw;
                                return label;
                            }
                        }
                    },
                    legend: {
                        display: true,
                        position: 'top'
                    }
                }
            }
        });

        var ctx7 = document.getElementById('chartContainer7').getContext('2d');
        var chart7 = new Chart(ctx7, {
            type: 'line',
            data: {
                labels: <?php echo json_encode(array_column($dataPoints9, 'date')); ?>,
                datasets: [{
                    label: '<?php echo htmlspecialchars($selectedFeature); ?>'+"'s "+"Average License Usage",
                    data: <?php echo json_encode(array_column($dataPoints9, 'avg_licenses')); ?>,
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: false,
						title: {
							display: true,
							text: 'Average License Issued',
							font: {
								size: 16, 
								family: 'Arial', 
								style: 'normal',
								lineHeight: 1.2
							},
							color: '#000', 
							padding: {top: 10, left: 0, right: 0, bottom: 10}
						}
                    },
					x: {
						title: {
							display: true,
							text: 'Date',
							font: {
								size: 16, 
								family: 'Arial', 
								style: 'normal',
								lineHeight: 1.2
							},
							color: '#000', 
							padding: {top: 10, left: 0, right: 0, bottom: 10}
						}
					}
                },
                plugins: {
					tooltip: {
						mode: 'index',
						intersect: false
                    },
					interaction: {
						mode: 'index', 
						intersect: false 
					},
                    title: {
                        display: true,
                        text: 'Average Number of Licenses Issued for ' + '<?php echo htmlspecialchars($selectedFeature); ?>',
                        padding: {
                            top: 10,
                            bottom: 10
                        },
                        font: {
                            size: 50
                        }
                    }
                }
            }
        });
		
		var ctx8 = document.getElementById('chartContainer8').getContext('2d');
        var chart8 = new Chart(ctx8, {
            type: 'line',
            data: {
                labels: <?php echo json_encode(array_column($dataPoints10, 'date')); ?>,
                datasets: [{
                    label: '<?php echo htmlspecialchars($selectedFeature); ?>'+"'s "+"User Count",
                    data: <?php echo json_encode(array_column($dataPoints10, 'user_count')); ?>,
                    borderWidth: 1,
                    pointBackgroundColor: 'rgba(75, 192, 192, 0.6)',
                    pointBorderColor: 'rgba(75, 192, 192, 1)',
                    pointBorderWidth: 1,
                    pointRadius: 2,
                    fill: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
						afterDataLimits: function(axis) {
							var max = axis.max;
							axis.max = max + Math.ceil(max * 0.25); 
						},
						ticks: {
						  stepSize: 1
						},
						title: {
							display: true,
							text: 'No. Of Users',
							font: {
								size: 16, 
								family: 'Arial', 
								style: 'normal',
								lineHeight: 1.2
							},
							color: '#000', 
							padding: {top: 10, left: 0, right: 0, bottom: 10}
						}
                    },
					x: {
						title: {
							display: true,
							text: 'Date',
							font: {
								size: 16, 
								family: 'Arial', 
								style: 'normal',
								lineHeight: 1.2
							},
							color: '#000', 
							padding: {top: 10, left: 0, right: 0, bottom: 10}
						}
					}
                },
                plugins: {
                    tooltip: {
						mode: 'index',
						intersect: false,
                        callbacks: {
                            label: function(context) {
                                var users = <?php echo json_encode(array_column($dataPoints10, 'users')); ?>;
                                return context.raw + ': ' + users[context.dataIndex];
                            }
                        }
                    },
					interaction: {
						mode: 'index', 
						intersect: false 
					},
                    title: {
                        display: true,
                        text: 'Number of ' + '<?php echo htmlspecialchars($selectedFeature); ?>'+ ' Users',
                        padding: {
                            top: 10,
                            bottom: 10
                        },
                        font: {
                            size: 50
                        }
                    }
                }
            }
        });
		
		
		var ctx9 = document.getElementById('chartContainer9').getContext('2d');
        var chart9 = new Chart(ctx9, {
            type: 'line',
            data: {
                labels: <?php echo json_encode(array_column($dataPoints12, 'date')); ?>,
                datasets: [{
                    label: '<?php echo htmlspecialchars($selectedFeature); ?>'+"'s "+"Average License Usage",
                    data: <?php echo json_encode(array_column($dataPoints12, 'avg_licenses')); ?>,
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: false,
						title: {
							display: true,
							text: 'Average License Issued',
							font: {
								size: 16, 
								family: 'Arial', 
								style: 'normal',
								lineHeight: 1.2
							},
							color: '#000', 
							padding: {top: 10, left: 0, right: 0, bottom: 10}
						}
                    },
					x: {
						title: {
							display: true,
							text: 'Date',
							font: {
								size: 16, 
								family: 'Arial', 
								style: 'normal',
								lineHeight: 1.2
							},
							color: '#000', 
							padding: {top: 10, left: 0, right: 0, bottom: 10}
						}
					}
                },
                plugins: {
					tooltip: {
						mode: 'index',
						intersect: false
                    },
					interaction: {
						mode: 'index', 
						intersect: false 
					},
                    title: {
                        display: true,
                        text: 'Average Number of Licenses Issued by ' + '<?php echo htmlspecialchars($selectedUser); ?>',
                        padding: {
                            top: 10,
                            bottom: 10
                        },
                        font: {
                            size: 50
                        }
                    }
                }
            }
        });
	
		
		var ctx10 = document.getElementById('chartContainer10').getContext('2d');
        var chart10 = new Chart(ctx10, {
            type: 'pie',
            data: {
                labels: <?php echo json_encode(array_column($dataPoints13, 'software')); ?>,
                datasets: [{
                    label: 'Licenses Issued per Software',
                    data: <?php echo json_encode(array_column($dataPoints13, 'total_licenses')); ?>,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.5)',
                        'rgba(54, 162, 235, 0.5)',
                        'rgba(255, 206, 86, 0.5)',
                        'rgba(75, 192, 192, 0.5)',
                        'rgba(153, 102, 255, 0.5)',
                        'rgba(255, 159, 64, 0.5)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 0.5)',
                        'rgba(54, 162, 235, 0.5)',
                        'rgba(255, 206, 86, 0.5)',
                        'rgba(75, 192, 192, 0.5)',
                        'rgba(153, 102, 255, 0.5)',
                        'rgba(255, 159, 64, 0.5)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Software Usage of '+'<?php echo $selectedUser ?>',
                        padding: {
                            top: 10,
                            bottom: 10
                        },
                        font: {
                            size: 50 
                        }
                    }
                }
            }
        });
		
		var ctx11 = document.getElementById('chartContainer11').getContext('2d');
        var chart11 = new Chart(ctx11, {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode(array_column($dataPoints14, 'feature')); ?>,
                datasets: [{
                    label: 'Licenses Issued per feature',
                    data: <?php echo json_encode(array_column($dataPoints14, 'total_licenses')); ?>,
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Feature Usage Of '+'<?php echo htmlspecialchars($selectedUser); ?>',
                        padding: {
                            top: 10,
                            bottom: 10
                        },
                        font: {
                            size: 50 
                        }
                    }
                }
            }
        });
		
    };
    </script>
</body>
</html>
