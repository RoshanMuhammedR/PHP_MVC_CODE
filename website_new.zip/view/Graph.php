<?php
class Graph {
    function getServerCount($conn, $user, $table) {
        $rows = $user->fetchTableData($conn, "SELECT lic_server, COUNT(*) as count FROM $table GROUP BY lic_server ORDER BY count(*) DESC");
        $server_names = [];
        $server_count = [];
        
        foreach ($rows as $row) {
            $server_names[] = $row['lic_server'];
            $server_count[] = $row['count'];
        }

        $dataPoints1 = [];
        $x = 10;

        for ($i = 0; $i < count($server_count); $i++) {
            $dataPoints1[] = ['x' => $x, 'y' => $server_count[$i], 'label' => $server_names[$i]];
            $x += 10;
        }

        return $dataPoints1;
    }

    function getSoftwareCount($conn, $user, $table){
        $rows = $user->fetchTableData($conn, "SELECT software, COUNT(*) as count FROM $table GROUP BY software ORDER BY count(*) DESC");
        $dataPoints2 = [];

        foreach ($rows as $row) {
            $dataPoints2[] = [
                "label" => $row["software"],
                "y" => $row["count"]
            ];
        }

        return $dataPoints2;
    }

    function getSoftwares($conn,$user,$table){
        $rows = $user->fetchTableData($conn,"SELECT DISTINCT(software) FROM $table;");
        return $rows;
    }

    function getFeature($conn,$user,$table){
        $rows = $user->fetchTableData($conn,"SELECT DISTINCT(feature) FROM $table;");
        return $rows;
    }

    function getLicensesPerFeature($conn,$user,$table,$from,$to){
        $rows = $user->fetchTableData($conn, "SELECT feature, SUM(licenses) as No_Of_licenses FROM $table WHERE start_time_standardized BETWEEN '$from' AND '$to'  GROUP BY feature");
        return $rows;
    }
    function getSoftwareFromTo($conn,$user,$table,$software,$from,$to){
        $sql = "
            SELECT date(start_time_standardized) as date, avg(licenses) as avg_licenses
            FROM $table
            WHERE software = '$software'
            AND start_time_standardized BETWEEN '$from' AND '$to'
            GROUP BY date(start_time_standardized)
            ORDER BY date(start_time_standardized)
        ";
        $rows = $user->fetchTableData($conn,$sql);
        return $rows;
    }

    function getFeatureFromTo($conn,$user,$table,$feature,$from,$to){
        $sql = "
            SELECT date(start_time_standardized) as date, avg(licenses) as avg_licenses
            FROM $table
            WHERE feature = '$feature'
            AND start_time_standardized BETWEEN '$from' AND '$to'
            GROUP BY date(start_time_standardized)
            ORDER BY date(start_time_standardized)
        ";
        $rows = $user->fetchTableData($conn,$sql);
        return $rows;
    }

    function getFeaturePerSoftware($conn,$user,$table,$software,$from,$to){
        if($software=="None Selected"){
            return;
        }
        $sql = "SELECT feature,SUM(licenses) FROM $table WHERE software = '$software' AND start_time_standardized BETWEEN '$from' AND '$to'  GROUP BY feature";
        $rows = $user->fetchTableData($conn,$sql);
        return $rows;
    }

    function getUserPerSoftware($conn,$user,$table,$software,$from,$to){
        $sql = "SELECT 
                    DATE(start_time_standardized) AS date,
                    COUNT(DISTINCT username) AS user_count,
                    GROUP_CONCAT(DISTINCT username ORDER BY username SEPARATOR ', ') AS users
                FROM 
                    $table 
                WHERE 
                    software = '$software' 
                    AND start_time_standardized BETWEEN '$from' AND '$to'
                GROUP BY 
                    DATE(start_time_standardized)
                ORDER BY 
                    DATE(start_time_standardized);
                ";
        $rows = $user->fetchTableData($conn,$sql);
        return $rows;
    }
}
?>