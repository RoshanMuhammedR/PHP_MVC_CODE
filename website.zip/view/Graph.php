<?php
class Graph {
    function getServerCount($conn, $user, $table) {
        $rows = $user->fetchTableData($conn, "SELECT lic_server, COUNT(*) as count FROM $table GROUP BY lic_server");
        $server_names = [];
        $server_count = [];
        
        foreach ($rows as $row) {
            $server_names[] = $row['lic_server'];
            $server_count[] = $row['count'];
        }

        $dataPoints1 = [];
        $x = 10;

        for ($i = 0; $i < count($server_count); $i++) {
            $dataPoints1[] = ['x' => $x, 'y' => $server_count[$i], 'label' => $server_names[$i]];
            $x += 10;
        }

        return $dataPoints1;
    }

    function getSoftwareCount($conn, $user, $table){
        $rows = $user->fetchTableData($conn, "SELECT software, COUNT(*) as count FROM $table GROUP BY software");
        $dataPoints2 = [];

        foreach ($rows as $row) {
            $dataPoints2[] = [
                "label" => $row["software"],
                "y" => $row["count"]
            ];
        }

        return $dataPoints2;
    }

    function getSoftwares($conn,$user,$table){
        $rows = $user->fetchTableData($conn,"SELECT DISTINCT(software) FROM $table;");
        return $rows;
    }

    function getFeature($conn,$user,$table){
        $rows = $user->fetchTableData($conn,"SELECT DISTINCT(feature) FROM $table;");
        return $rows;
    }

    function getLicensesPerFeature($conn,$user,$table){
        $rows = $user->fetchTableData($conn, "SELECT feature, SUM(licenses) as No_Of_licenses FROM $table GROUP BY feature");
        $feature_name = [];
        $license_count = [];

        foreach ($rows as $row) {
            $feature_name[] = $row['feature'];
            $license_count[] = $row['No_Of_licenses'];
        }
        $dataPoints = [];
        $x = 5;

        for ($i = 0; $i < count($license_count); $i++) {
            $dataPoints[] = ['x' => $x, 'y' => $license_count[$i], 'label' => $feature_name[$i]];
            $x += 5;
        }

        usort($dataPoints, function($a, $b) {
            return $b['y'] - $a['y'];
        });
        $top6 = array_slice($dataPoints, 0, 6);
        $otherCount = array_sum(array_column(array_slice($dataPoints, 6), 'y'));
        
        if ($otherCount > 0) {
            $top6[] = ["label" => "Others", "y" => $otherCount];
        }
        $x=10;
        foreach ($top6 as &$dataPoint) {
            $dataPoint['x'] = $x;
            $x += 10;
        }
        return $top6;
    }
}
?>