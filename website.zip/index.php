<?php
include("src/App/Model/User.php");
include("View/Graph.php");

$table = "licenseuserhistory_correct2";
$user = new User;
$graph = new Graph;
$conn = $user->getConnection("localhost", "hpc", "root", "");
$dataPoints1 = $graph->getServerCount($conn, $user, $table);
$dataPoints2 = $graph->getSoftwareCount($conn, $user, $table);
$dataPoints3 = $graph->getSoftwares($conn, $user, $table);
$dataPoints4 = $graph->getFeature($conn, $user, $table);

$selectedSoftware = $_POST['software'] ?? $_GET['software'] ?? 'None Selected';
$selectedFeature = $_POST['feature'] ?? $_GET['feature'] ?? 'None Selected';
$fromDate = $_POST['from_date']??$_GET['from_date']?? 'None Selected';
$toDate = $_POST['to_date']??$_GET['to_date']?? 'None Selected';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Graph Display</title>
    <style>
        .grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            grid-template-rows: auto auto;
            gap: 20px;
            padding: 20px;
        }
        .chartContainer {
            max-width: 600px;
            max-height: 400px;
            width: 100%;
            height: 100%;
        }
        .software-count {
            grid-column: span 2;
            text-align: center;
        }
		.date-from-to{
			display : flex;
			justify-content: center;
		}
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="grid">
        <canvas id="chartContainer1" class="chartContainer"></canvas>
        <canvas id="chartContainer2" class="chartContainer"></canvas>
        <div class="software-count">
            <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="get">
                <select name="software">
                    <?php
                        foreach($dataPoints3 as $row){
                            $selected = ($row['software'] == $selectedSoftware) ? 'selected' : '';
                            echo "<option value='" . htmlspecialchars($row['software']) . "' $selected>" . htmlspecialchars($row['software']) . "</option>";
                        }
                    ?>
                </select>
                <select name="feature">
                    <?php
                        foreach($dataPoints4 as $row){
                            $selected = ($row['feature'] == $selectedFeature) ? 'selected' : '';
                            echo "<option value='" . htmlspecialchars($row['feature']) . "' $selected>" . htmlspecialchars($row['feature']) . "</option>";
                        }
                    ?>
                </select>
				<div class="date-from-to">
					<div style = "display:flex;">
						<div>
							<h4>From:
							<input type="date"
								   id="Test_DatetimeLocal"
								   name = "from_date"
								   min="2015-01-01T00:00"
								   max="2025-12-31T23:59"
								   step="1">
							</h4>
						</div>
					
						<div>
							<h4>To:
							<input type="date"
								   id="Test_DatetimeLocal"
								   name = "to_date"
								   min="2015-01-01T00:00"
								   max="2025-12-31T23:59"
								   step="1">
							</h4>
						</div>
						</div>
				</div>
				
                <input type="submit">
            </form>
            <?php
				echo "You have selected: <br>";
				echo "Software: " . htmlspecialchars($selectedSoftware) . "<br>";
				echo "Feature: " . htmlspecialchars($selectedFeature) . "<br>";
				echo "From Date: " . htmlspecialchars(date('d-m-Y', strtotime($fromDate))) . "<br>";
				echo "To Date: " . htmlspecialchars(date('d-m-Y', strtotime($toDate))) . "<br>";
            ?>
        </div>
    </div>
    <script>
    window.onload = function () {
        var ctx1 = document.getElementById('chartContainer1').getContext('2d');
        var chart1 = new Chart(ctx1, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_column($dataPoints1, 'label')); ?>,
                datasets: [{
                    label: 'Licenses Issued per Server',
                    data: <?php echo json_encode(array_column($dataPoints1, 'y')); ?>,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.5)',
                        'rgba(54, 162, 235, 0.5)',
                        'rgba(255, 206, 86, 0.5)',
                        'rgba(75, 192, 192, 0.5)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 0.5)',
                        'rgba(54, 162, 235, 0.5)',
                        'rgba(255, 206, 86, 0.5)',
                        'rgba(75, 192, 192, 0.5)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
				
            }
        });

        var ctx2 = document.getElementById('chartContainer2').getContext('2d');
        var chart2 = new Chart(ctx2, {
            type: 'pie',
            data: {
                labels: <?php echo json_encode(array_column($dataPoints2, 'label')); ?>,
                datasets: [{
                    label: 'Licenses Issued per Software',
                    data: <?php echo json_encode(array_column($dataPoints2, 'y')); ?>,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.5)',
                        'rgba(54, 162, 235, 0.5)',
                        'rgba(255, 206, 86, 0.5)',
                        'rgba(75, 192, 192, 0.5)',
                        'rgba(153, 102, 255, 0.5)',
                        'rgba(255, 159, 64, 0.5)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
            }
        });
    }
    </script>
</body>
</html>
